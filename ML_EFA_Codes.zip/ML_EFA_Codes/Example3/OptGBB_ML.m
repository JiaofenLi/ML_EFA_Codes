function out = OptGBB_ML(Q, D, Psi, fun, opts, R)
%OPTGBB_ML  OptGBB method for ML factor analysis.
%
% Minimizes:
%   f = log(det(Sigma)) + trace(Sigma^{-1} R),
%   Sigma = Q*(D^2)*Q' + (Psi^2),
% where Q has orthonormal columns, and D, Psi are diagonal.
%
% Inputs:
%   Q     - p-by-q matrix with (approximately) orthonormal columns
%   D     - q-by-q diagonal matrix
%   Psi   - p-by-p diagonal matrix
%   fun   - function handle: [f,Gq,Gd,Gpsi,nrmGrad] = fun(Q,D,Psi,R)
%   opts  - struct with fields:
%             .gtol   (gradient tolerance)
%             .ftol   (function value change tolerance)
%             .mxitr  (maximum iterations)
%   R     - p-by-p symmetric correlation/covariance matrix
%
% Output (struct):
%   out.Q, out.D, out.Psi, out.fval, out.nrmGrad, out.df, out.itr, out.feasi_q

% -------- options --------
maxItr = opts.mxitr;
gtol   = opts.gtol;   % gradient tolerance
ftol   = opts.ftol;   % function value change tolerance

delta  = 1e-4;    % line-search parameter
gamma  = 0.85;    % nonmonotone averaging parameter
lambda = 0.2;     % backtracking shrink factor
alpha  = 1e-3;    % initial step length

% -------- basic checks / projections (safe) --------
[p, q] = size(Q);

R   = 0.5 * (R + R');
D   = diag(diag(D));
Psi = diag(diag(Psi));

% -------- initial evaluation --------
[F, Gq, Gd, Gpsi, nrmGrad] = feval(fun, Q, D, Psi, R);

dtQ   = -Gq;
dtD   = -Gd;
dtPsi = -Gpsi;

TT      = zeros(maxItr, 1);   % gradient norm history
Time    = zeros(maxItr, 1);   % time history
DF      = zeros(maxItr, 1);   % function value change history
DF(1)   = inf;
TT(1)   = nrmGrad;
Time(1) = 0;

Cval = F;
QQ   = 1;

tStart = tic;

% -------- main loop --------
for itr = 2:maxItr
    Q_old   = Q;    D_old   = D;    Psi_old = Psi;
    dtQ_old = dtQ;  dtD_old = dtD;  dtPsi_old = dtPsi;
    F_old   = F;    % Save previous function value

    % ---- nonmonotone backtracking line search ----
    deriv = delta * (nrmGrad^2);
    nls   = 1;
    alpha_ls = alpha;  % keep a local copy for this line search

    while true
        D_trial   = D_old   + alpha_ls * dtD_old;
        Psi_trial = Psi_old + alpha_ls * dtPsi_old;

        Qtan = Q_old + alpha_ls * dtQ_old;
        [Q_trial, ~] = qr(Qtan, 0);

        [F_new, Gq_new, Gd_new, Gpsi_new, nrmGrad_new] = feval(fun, Q_trial, D_trial, Psi_trial, R);

        if (F_new <= Cval - alpha_ls * deriv) || (nls >= 10)
            Q = Q_trial; D = D_trial; Psi = Psi_trial;
            F = F_new;   Gq = Gq_new; Gd = Gd_new; Gpsi = Gpsi_new;
            nrmGrad = nrmGrad_new;
            break;
        end

        alpha_ls = lambda * alpha_ls;
        nls = nls + 1;
    end

    % ---- compute function value change ----
    df = F - F_old;

    % ---- record history ----
    TT(itr)   = nrmGrad;
    Time(itr) = toc(tStart);
    DF(itr)   = df;

    % ---- stopping test: gradient norm OR function value change ----
    if (nrmGrad <= gtol) && (abs(df) <= ftol)
        break;
    end

    % ---- update descent directions ----
    dtQ   = -Gq;
    dtD   = -Gd;
    dtPsi = -Gpsi;

    % ---- BB step length (use vector form for diagonal parts) ----
    Sq = Q - Q_old;
    Yq = dtQ - dtQ_old;

    Sd   = diag(D)   - diag(D_old);
    Yd   = diag(dtD) - diag(dtD_old);

    Spsi = diag(Psi)   - diag(Psi_old);
    Ypsi = diag(dtPsi) - diag(dtPsi_old);

    SY = sum(sum(Sq .* Yq)) + (Sd' * Yd) + (Spsi' * Ypsi);
    SS = sum(sum(Sq .* Sq)) + (Sd' * Sd) + (Spsi' * Spsi);
    YY = sum(sum(Yq .* Yq)) + (Yd' * Yd) + (Ypsi' * Ypsi);

    if mod(itr, 2) == 0
        alpha = SS / max(abs(SY), eps);
    else
        alpha = abs(SY) / max(YY, eps);
    end
    alpha = max(min(alpha, 1e20), 1e-20);

    % ---- update nonmonotone reference value ----
    QQ_old = QQ;
    QQ     = gamma * QQ_old + 1;
    Cval   = (gamma * QQ_old * Cval + F) / QQ;
end

% -------- trim histories --------
TT   = TT(1:itr);
Time = Time(1:itr);
DF   = DF(1:itr);

% -------- output --------
out.Q       = Q;
out.D       = diag(diag(D));
out.Psi     = diag(diag(Psi));
out.fval    = F;
out.nrmGrad = nrmGrad;
out.f_change = DF(end);          % final function value change
out.itr     = itr;
out.TT      = TT;
out.Time    = Time;
out.DF      = DF;               % function value change history
out.feasi_q = norm(Q' * Q - eye(q), 'fro');

if itr >= maxItr
    out.msg = 'Exceeded maximum iteration limit.';
end
end