function main_ODE_Compare_ML_random_data
%MAIN_ODE_COMPARE_ML  Compare OptGBB vs. ODE solvers for ML factor analysis.
%
% This script:
%   1) Generates a true ML factor-analysis correlation matrix R_true.
%   2) Draws samples from N(0, R_true).
%   3) Builds sample correlation matrix R.
%   4) Runs OptGBB and ODE-based methods (ode15s/ode45/ode113).
%
% Notes:
%   - Requires: fun_ML.m, OptGBB_ML.m, ODE_ML.m in the MATLAB path.

clc;
close all;

%% -------------------- options --------------------
opts.gtol        = 1e-6;
opts.ftol        = 1e-8;
opts.mxitr_ODE   = 20000;
opts.mxitr       = 10000;

%% -------------------- display header --------------------
disp('======================================================================');
fprintf('%12s\t  %3s %3s\t %7s\t %9s\t %10s\t %10s\t %10s\n', ...
    'method', 'n', 'q', 'CPU', 'IT', 'nrmg', '|df|', 'Fvalue');
disp('----ML Factor Analysis-----');

%% -------------------- test cases --------------------
N_list = [50,50,50,100,100,100,200,200,200,300,300,300,500,500,500,1000,1000,1000];
q_list = [ 3, 5, 8,  5,  8, 10,  5, 10, 15,  5, 10, 15,  5, 10, 20,   5,  20,  30];

N_samples = 2000;
odeMethods = {'ode15s', 'ode45', 'ode113'};

for kCase = 1:numel(N_list)
    n = N_list(kCase);
    q = q_list(kCase);

    %% ----- build sample correlation matrix R -----
    R_true = generate_true_model_ML(n, q);
    X      = generate_multivariate_normal(R_true, N_samples);
    R      = corrcoef(X);
    R      = 0.5 * (R + R');

    lamMin = min(eig(R));
    if lamMin < 1e-8
        R = R + (abs(lamMin) + 1e-8) * eye(n);
    end

    %% ----- initialization -----
    [Q0, D0, Psi0] = initialMatrices_ML(R, q);

    %% ----- OptGBB -----
    tStart = tic;
    outOpt = OptGBB_ML(Q0, D0, Psi0, @fun_ML, opts, R);
    tOpt   = toc(tStart);

    fprintf('%12s\t %3d %3d\t %7.3f\t %9d\t %10.2e\t %10.2e\t %10.4f\n', ...
        'OptGBB', n, q, tOpt, outOpt.itr, outOpt.nrmGrad, abs(outOpt.f_change), outOpt.fval);

    % ----- ODE solvers -----
    for iMethod = 1:numel(odeMethods)
        method = odeMethods{iMethod};

        tStart = tic;
        outODE = ODE_ML(Q0, D0, Psi0, @fun_ML, opts, R, method);
        tODE   = toc(tStart);

        fprintf('%12s\t %3d %3d\t %7.3f\t %9d\t %10.2e\t %10.2e\t %10.4f\n', ...
            method, n, q, tODE, outODE.itr, outODE.nrmGrad, abs(outODE.df), outODE.fval);
    end

    disp('--------------------------------------------------------------------------------------');
end

end

%% ======================================================================
%  Helper functions (unchanged)
% ======================================================================
function R = generate_true_model_ML(n, q)
rng(2, 'twister');
A = randn(n, q);
[Q, ~] = qr(A, 0);
D   = diag(0.8 + 0.4 * rand(q, 1));
Psi = diag(0.2 + 0.3 * rand(n, 1));
Sigma = Q * (D.^2) * Q' + diag(diag(Psi.^2));
s = 1 ./ sqrt(diag(Sigma));
R = diag(s) * Sigma * diag(s);
R = 0.5 * (R + R');
end

function X = generate_multivariate_normal(Sigma, N_samples)
n = size(Sigma, 1);
lamMin = min(eig(Sigma));
if lamMin < 1e-8
    Sigma = Sigma + (abs(lamMin) + 1e-8) * eye(n);
end
[L, flag] = chol(Sigma, 'lower');
if flag ~= 0
    [U, S, ~] = svd(Sigma);
    L = U * sqrt(S);
end
Z = randn(n, N_samples);
X = (L * Z)';
end

function [Q0, D0, Psi0] = initialMatrices_ML(R, q)
[U, Lambda] = eigs(R, q);
Q0 = U;
eigvals = diag(Lambda);
d2 = max(eigvals - 1, 0);
D0 = diag(sqrt(d2));
R_recon = Q0 * (D0^2) * Q0';
res = diag(R - R_recon);
Psi0 = diag(sqrt(max(res, 0.01)));
end