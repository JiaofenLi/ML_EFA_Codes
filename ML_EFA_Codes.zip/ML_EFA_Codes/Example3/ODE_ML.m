function out = ODE_ML(Q, D, Psi, fun, opts, R, method)
%ODE_ML  ODE-based negative-gradient flow for ML factor analysis.
%
% Integrates the ODE:
%   d/dt [vec(Q); diag(D); diag(Psi)] = -[vec(Gq); diag(Gd); diag(Gpsi)].
%
% After each integration window, Q is re-orthonormalized by QR, and D/Psi
% are forced to be diagonal (we store only their diagonals in the ODE state).
%
% Inputs:
%   Q      - p-by-q initial orthonormal matrix
%   D      - q-by-q diagonal matrix
%   Psi    - p-by-p diagonal matrix
%   fun    - handle: [f,Gq,Gd,Gpsi,nrmGrad] = fun(Q,D,Psi,R)
%   opts   - struct with fields: gtol, ftol, mxitr_ODE
%   R      - p-by-p symmetric correlation/covariance matrix
%   method - 'ode15s', 'ode45', or 'ode113' (optional)
%
% Output:
%   out    - struct: .Q .D .Psi .fval .nrmGrad .df .itr .time .msg (optional)

% -------------------- defaults / basic checks --------------------

if ~isfield(opts, 'gtol'),      opts.gtol = 1e-6;      end
if ~isfield(opts, 'ftol'),      opts.ftol = 1e-6;      end
if ~isfield(opts, 'mxitr_ODE'), opts.mxitr_ODE = 20000;  end

[p, q] = size(Q);
if ~isequal(size(D), [q, q]) || ~isequal(size(Psi), [p, p]) || ~isequal(size(R), [p, p])
    error('Dimension mismatch among Q, D, Psi, and R.');
end

R   = 0.5 * (R + R');
D   = diag(diag(D));
Psi = diag(diag(Psi));

% -------------------- initial evaluation --------------------
[fval, ~, ~, ~, nrmGrad] = feval(fun, Q, D, Psi, R);

% Pack ODE state: [Q(:); diag(D); diag(Psi)]
x0 = [Q(:); diag(D); diag(Psi)];

% ODE settings
tspan = [0, 1, 10];  % one integration window per outer loop
odeOpts = odeset('RelTol', 1e-10, 'AbsTol', 1e-10, 'Stats', 'off');

totalIter = 0;
timeCost  = 0;
abs_df    = inf;

% -------------------- outer loop --------------------
for outer = 1:opts.mxitr_ODE
    % ---- stopping test: gradient norm OR function value change ----
    if (nrmGrad <= opts.gtol) && (abs(abs_df) <= opts.ftol)
        break;
    end

    f_old = fval;

    tStart = clock;

    % Choose solver
    switch method
        case 'ode15s'
            [~, X, stats] = ode15s(@ode_rhs, tspan, x0, odeOpts);
        case 'ode45'
            [~, X, stats] = ode45(@ode_rhs, tspan, x0, odeOpts);
        case 'ode113'
            [~, X, stats] = ode113(@ode_rhs, tspan, x0, odeOpts);
        otherwise
            error('Unknown ODE solver. Use ode15s, ode45, or ode113.');
    end

    timeCost  = timeCost + etime(clock, tStart);
    totalIter = totalIter +  stats(1);

    % Take last state and unpack
    xEnd = X(end, :)';
    Q = reshape(xEnd(1:p*q), p, q);
    d = xEnd(p*q + 1 : p*q + q);
    psi = xEnd(p*q + q + 1 : end);

    D   = diag(d);
    Psi = diag(psi);

    % Project back to constraints
    [Q, ~] = qr(Q, 0);
    D      = diag(diag(D));
    Psi    = diag(diag(Psi));

    % Re-evaluate
    [fval, ~, ~, ~, nrmGrad] = feval(fun, Q, D, Psi, R);
    abs_df = fval - f_old;

    % Re-pack for next window
    x0 = [Q(:); diag(D); diag(Psi)];
end

% -------------------- output --------------------
out.Q       = Q;
out.D       = D;
out.Psi     = Psi;
out.fval    = fval;
out.nrmGrad = nrmGrad;
out.df      = abs_df;          % final function value change
out.itr     = totalIter;
out.time    = timeCost;

% -------------------- nested RHS (kept minimal) --------------------
    function dx = ode_rhs(~, x)
        % Unpack
        Qloc = reshape(x(1:p*q), p, q);
        dloc = x(p*q + 1 : p*q + q);
        psiloc = x(p*q + q + 1 : end);

        Dloc   = diag(dloc);
        Psiloc = diag(psiloc);

        % Negative gradient flow
        [~, Gq, Gd, Gpsi, ~] = feval(fun, Qloc, Dloc, Psiloc, R);

        dx = [-Gq(:); -diag(Gd); -diag(Gpsi)];
    end
end