function results = main_Example1
% MAIN_EXAMPLE1 ML factor extraction and Kaiser-normalized Varimax rotation.
% Requires the updated fun_ML.m and OptGBB_ML.m on the MATLAB path.

clc;
close all;

result_dir = 'MLE_Kaiser_Results_Fixed';

if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end

diaryFile = fullfile(result_dir, 'MLE_Kaiser_Rotation_output.txt');

if exist(diaryFile, 'file')
    delete(diaryFile);
end

diary(diaryFile);
logCleanup = onCleanup(@() diary('off')); %#ok<NASGU>

%% ----- 1. Input matrix and factor count -----
var_names = {'Application', 'Appearance', 'Academic', 'Likability', ...
    'SelfControl', 'Comprehension', 'Honesty', 'SalesAbility', ...
    'Experience', 'Driving', 'Ambition', 'Insight', 'Potential', ...
    'Cooperation', 'Distribution'};

R_original = [
    1.00  0.24  0.04  0.31  0.09  0.23 -0.11  0.27  0.55  0.35  0.28  0.34  0.37  0.47  0.59;
    0.24  1.00  0.12  0.38  0.43  0.37  0.35  0.48  0.14  0.34  0.55  0.51  0.51  0.28  0.38;
    0.04  0.12  1.00  0.00  0.00  0.08 -0.03  0.05  0.27  0.09  0.04  0.20  0.29 -0.32  0.14;
    0.31  0.38  0.00  1.00  0.30  0.48  0.65  0.35  0.14  0.39  0.35  0.50  0.61  0.69  0.33;
    0.09  0.43  0.00  0.30  1.00  0.81  0.41  0.82  0.02  0.70  0.04  0.72  0.68  0.48  0.25;
    0.23  0.37  0.08  0.48  0.81  1.00  0.36  0.83  0.15  0.70  0.76  0.88  0.78  0.53  0.42;
    -0.11  0.35 -0.03  0.65  0.41  0.36  1.00  0.23 -0.16  0.28  0.21  0.39  0.42  0.45  0.00;
    0.27  0.48  0.05  0.35  0.82  0.83  0.23  1.00  0.23  0.81  0.86  0.77  0.73  0.55  0.55;
    0.55  0.14  0.27  0.14  0.02  0.15 -0.16  0.23  1.00  0.34  0.20  0.30  0.35  0.21  0.69;
    0.35  0.34  0.09  0.39  0.70  0.70  0.28  0.81  0.34  1.00  0.78  0.71  0.79  0.61  0.62;
    0.28  0.55  0.04  0.35  0.04  0.76  0.21  0.86  0.20  0.78  1.00  0.78  0.77  0.55  0.43;
    0.34  0.51  0.20  0.50  0.72  0.88  0.39  0.77  0.30  0.71  0.78  1.00  0.88  0.55  0.53;
    0.37  0.51  0.29  0.61  0.68  0.78  0.42  0.73  0.35  0.79  0.77  0.88  1.00  0.54  0.57;
    0.47  0.28 -0.32  0.69  0.48  0.53  0.45  0.55  0.21  0.61  0.55  0.55  0.54  1.00  0.40;
    0.59  0.38  0.14  0.33  0.25  0.42  0.00  0.55  0.69  0.62  0.43  0.53  0.57  0.40  1.00
    ];

n_vars = numel(var_names);
n_show = min(6, n_vars);

% Preserve the original data and the original diagonal-shift procedure.
% The shifted input is not an empirical unit-diagonal correlation matrix.
R_corr = 0.5 * (R_original + R_original');
lambda_min = min(eig(R_corr));
diagonal_shift = max(0, 1e-8 - lambda_min);
R_corr = R_corr + diagonal_shift * eye(n_vars);

fprintf('\n=== Interview data: input and eigenvalue analysis ===\n');
fprintf('Number of variables: %d\n', n_vars);
fprintf('Original minimum eigenvalue: %.8f\n', lambda_min);
fprintf('Applied diagonal shift: %.8e\n', diagonal_shift);

print_matrix('Processed input R: first six variables', ...
    R_corr(1:n_show, 1:n_show), ...
    var_names(1:n_show), var_names(1:n_show));

[V, E] = eig(R_corr);
[eigenvalues, order] = sort(diag(E), 'descend');
V = V(:, order);
contribution_rates = eigenvalues / sum(eigenvalues);
cumulative_var = cumsum(contribution_rates);

% Retain the original eigenvalue > 1 rule for the processed input.
n_factors = max(1, sum(eigenvalues > 1));
retained_pca_share = 100 * sum(contribution_rates(1:n_factors));
factor_labels = arrayfun(@(j) sprintf('F%d', j), ...
    1:n_factors, 'UniformOutput', false);

fprintf('\nComponent  Eigenvalue  PCA variance (%%)  Cumulative (%%)\n');

for j = 1:n_vars
    fprintf('%9d  %10.4f  %16.2f  %14.2f\n', ...
        j, eigenvalues(j), 100 * contribution_rates(j), ...
        100 * cumulative_var(j));
end

fprintf('Selected factors: q = %d; retained PCA variance: %.2f%%\n', ...
    n_factors, retained_pca_share);

%% ----- 2. PCA initialization and ML fitting -----
% Reuse the eigendecomposition instead of computing it again with eigs.
Q0 = V(:, 1:n_factors);
D0 = diag(sqrt(max(eigenvalues(1:n_factors) - 1, 0.001)));
residual = diag(R_corr - Q0 * (D0 ^ 2) * Q0');
Psi0 = diag(sqrt(max(residual, 0.01)));

[f0, ~, ~, ~, grad_norm0] = fun_ML(Q0, D0, Psi0, R_corr);




opts.gtol = 1e-5;
opts.mxitr = 5000;

fprintf('\n=== PCA initialization and OptGBB fit ===\n');
fprintf('Initial objective: %.10f\n', f0);
fprintf('Initial product-manifold gradient norm: %.3e\n', grad_norm0);

print_matrix('Initial Q: first six rows', ...
    Q0(1:n_show, :), var_names(1:n_show), factor_labels);


fprintf('Initial Q: \n');
fprintf([repmat('%9.4f ', 1, size(Q0, 2)), '\n'], Q0');
fprintf('Initial D diagonal: ');
fprintf('%.4f ', diag(D0));
fprintf('\nInitial Psi diagonal: ');
fprintf('%.4f ', diag(Psi0));
fprintf('\n');

tStart = tic;
out = OptGBB_ML(Q0, D0, Psi0, @fun_ML, opts, R_corr);
tOpt = toc(tStart);
success = out.nrmGrad <= opts.gtol;

Sigma_opt = out.Q * (out.D ^ 2) * out.Q' + out.Psi ^ 2;
Loadings = out.Q * out.D;

fprintf('\nMethod    p   q   CPU (s)   IT    Gradient norm       df         Objective\n');
fprintf('OptGBB  %3d %3d %9.3f %5d %16.3e %12.3e %17.10f\n', ...
    n_vars, n_factors, tOpt, out.itr, out.nrmGrad, out.df, out.fval);
fprintf('Gradient target: %.1e; success: %d\n', opts.gtol, success);
fprintf('Previous objective: %.15e\n', out.fprev);
fprintf('Terminal objective: %.15e\n', out.fval);

print_matrix('Terminal Q: first six rows', ...
    out.Q(1:n_show, :), var_names(1:n_show), factor_labels);

fprintf('Terminal Q: \n');
fprintf([repmat('%9.4f ', 1, size(Q0, 2)), '\n'], out.Q');
fprintf('Terminal D diagonal: ');
fprintf('%.4f ', diag(out.D));
fprintf('\nTerminal Psi diagonal: ');
fprintf('%.4f ', diag(out.Psi));
fprintf('\n');

print_matrix('Fitted covariance: first six variables', ...
    Sigma_opt(1:n_show, 1:n_show), ...
    var_names(1:n_show), var_names(1:n_show));

%% ----- 3. Kaiser-normalized Varimax rotation -----
sqrt_h2 = sqrt(max(sum(Loadings .^ 2, 2), eps));
Loadings_norm = Loadings ./ sqrt_h2;
max_rounds = 10000;
rotation_tol = 1e-10;

[Loadings_rot_norm, R_rot, fval_history] = ...
    kaiser_rotation(Loadings_norm, max_rounds, rotation_tol);

% Do not clip: an orthogonal rotation must preserve the fitted covariance.
Loadings_rot = Loadings_rot_norm .* sqrt_h2;
rotation_orth_error = norm(R_rot' * R_rot - eye(n_factors), 'fro');
rotation_map_error = norm(Loadings_rot - Loadings * R_rot, 'fro');
covariance_change = norm(Loadings_rot * Loadings_rot' - ...
    Loadings * Loadings', 'fro');

fprintf('\n=== Kaiser-normalized Varimax rotation ===\n');
fprintf('Completed sweeps: %d\n', numel(fval_history) - 1);
fprintf('Varimax criterion: %.10f -> %.10f\n', ...
    fval_history(1), fval_history(end));
fprintf('Rotation orthogonality error: %.3e\n', rotation_orth_error);
fprintf('Loading-map error: %.3e; covariance change: %.3e\n', ...
    rotation_map_error, covariance_change);

print_matrix('Unrotated loadings', Loadings, var_names, factor_labels);
print_matrix('Rotation matrix', R_rot, factor_labels, factor_labels);
print_matrix('Rotated loadings', Loadings_rot, var_names, factor_labels);

%% ----- 4. Variance shares and high-loading variables -----
model_variance = trace(Sigma_opt);
factor_variance = [sum(Loadings .^ 2, 1); sum(Loadings_rot .^ 2, 1)];
factor_share = 100 * factor_variance / model_variance;
cumulative_share = cumsum(factor_share, 2);
common_vs_total = sum(factor_share(2, :));
unique_vs_total = 100 * sum(diag(out.Psi) .^ 2) / model_variance;

fprintf('\n=== Shares of fitted model variance ===\n');
fprintf('Factor  Before: variance / share / cumulative   After: variance / share / cumulative\n');

for j = 1:n_factors
    fprintf('F%-5d %10.4f %9.2f%% %9.2f%%    %10.4f %9.2f%% %9.2f%%\n', ...
        j, factor_variance(1, j), factor_share(1, j), cumulative_share(1, j), ...
        factor_variance(2, j), factor_share(2, j), cumulative_share(2, j));
end

fprintf('Common-factor share: %.2f%%; uniqueness share: %.2f%%\n', ...
    common_vs_total, unique_vs_total);

threshold = 0.5;

for j = 1:n_factors
    [~, order] = sort(abs(Loadings_rot(:, j)), 'descend');
    selected = order(abs(Loadings_rot(order, j)) > threshold);
    fprintf('\nFactor F%d: %d variables with |loading| > %.2f\n', ...
        j, numel(selected), threshold);

    for k = 1:numel(selected)
        i = selected(k);
        fprintf('  %-16s %.4f\n', var_names{i}, Loadings_rot(i, j));
    end
end

%% ----- 5. Figures -----
fig = figure('Name', 'Scree plot', 'Color', 'w', ...
    'Position', [150, 150, 750, 400]);
plot(1:n_vars, eigenvalues, 'b-o', 'LineWidth', 1.5);
hold on;
plot([1, n_vars], [1, 1], 'r--', 'LineWidth', 1.2);
plot([n_factors + 0.5, n_factors + 0.5], ylim, 'g--', 'LineWidth', 1.2);
hold off;
xlabel('Principal component index');
ylabel('Eigenvalue of the processed input');
grid on;
save_plot(fig, result_dir, 'Scree_Plot');

fig = figure('Name', 'OptGBB convergence', 'Color', 'w', ...
    'Position', [100, 100, 1100, 440]);
iterations = 0:(out.itr - 1);

subplot(1, 2, 1);
plot(iterations, out.Fhistory, 'b-', 'LineWidth', 1.5);
xlabel('Iteration index');
ylabel('Likelihood objective');
grid on;

subplot(1, 2, 2);
semilogy(iterations, max(out.TT, eps), 'r-', 'LineWidth', 1.5);
hold on;
plot([0, max(1, out.itr - 1)], [opts.gtol, opts.gtol], 'k--');
hold off;
xlabel('Iteration index');
ylabel('Riemannian gradient norm');
legend('OptGBB', 'Gradient tolerance', 'Location', 'best');
grid on;
save_plot(fig, result_dir, 'OptGBB_Convergence');

fig = figure('Name', 'Varimax convergence', 'Color', 'w', ...
    'Position', [100, 100, 1100, 440]);
sweeps = 0:(numel(fval_history) - 1);

subplot(1, 2, 1);
plot(sweeps, fval_history, 'b-o', 'LineWidth', 1.5);
xlabel('Completed sweeps');
ylabel('Varimax criterion \phi');
grid on;

subplot(1, 2, 2);
semilogy(sweeps(2:end), max(abs(diff(fval_history)), eps), ...
    'b-o', 'LineWidth', 1.5);
hold on;
plot([1, max(2, sweeps(end))], [rotation_tol, rotation_tol], 'r--');
hold off;
xlabel('Completed sweeps');
ylabel('Absolute criterion change |\Delta\phi|');
legend('Varimax', 'Sweep tolerance', 'Location', 'best');
grid on;
save_plot(fig, result_dir, 'MLE_Kaiser_Convergence');

fig = figure('Name', 'Loading heatmaps', 'Color', 'w', ...
    'Position', [50, 150, 1100, 600]);
loading_matrices = {Loadings, Loadings_rot};
panel_titles = {'Unrotated loadings', 'Varimax loadings'};
color_limit = max(1, max(abs([Loadings(:); Loadings_rot(:)])));
positions = [0.09, 0.12, 0.35, 0.76; 0.55, 0.12, 0.35, 0.76];
map = jet(256);
ax = cell(1, 2);

for k = 1:2
    ax{k} = axes('Position', positions(k, :));
    B = loading_matrices{k};
    imagesc(B, [-color_limit, color_limit]);
    colormap(ax{k}, map);
    set(ax{k}, 'XTick', 1:n_factors, 'XTickLabel', factor_labels, ...
        'YTick', 1:n_vars, 'YTickLabel', var_names, ...
        'TickLabelInterpreter', 'none', 'FontSize', 9);
    xlabel('Common factor');
    title(panel_titles{k});

    for i = 1:n_vars
        for j = 1:n_factors
            color_index = 1 + round(255 * (B(i, j) + color_limit) / (2 * color_limit));
            luminance = map(color_index, :) * [0.299; 0.587; 0.114];
            text_color = double(luminance < 0.5) * [1, 1, 1];
            text(j, i, sprintf('%.2f', B(i, j)), ...
                'HorizontalAlignment', 'center', 'Color', text_color, 'FontSize', 8);
        end
    end
end

cb = colorbar(ax{2});
set(cb, 'Position', [0.94, 0.12, 0.02, 0.76]);
ylabel(cb, 'Loading');
save_plot(fig, result_dir, 'MLE_Heatmap_Comparison');

if n_factors >= 2
    fig = figure('Name', 'Loading scatter plots', 'Color', 'w', ...
        'Position', [180, 180, 1150, 500]);
    pair_values = [Loadings(:, 1:2); Loadings_rot(:, 1:2)];
    plot_limit = max(1.1, 1.1 * max(abs(pair_values(:))));
    circle_angle = linspace(0, 2 * pi, 150);

    for k = 1:2
        subplot(1, 2, k);
        B = loading_matrices{k};
        scatter(B(:, 1), B(:, 2), 60, 'b', 'filled');
        hold on;
        plot([-plot_limit, plot_limit], [0, 0], 'k--');
        plot([0, 0], [-plot_limit, plot_limit], 'k--');
        plot(cos(circle_angle), sin(circle_angle), 'k-');

        for i = 1:n_vars
            text(B(i, 1) + 0.02, B(i, 2) + 0.02, var_names{i}, ...
                'FontSize', 8, 'Interpreter', 'none');
        end

        hold off;
        xlabel('Factor 1 loading');
        ylabel('Factor 2 loading');
        title(panel_titles{k});
        axis equal;
        axis([-plot_limit, plot_limit, -plot_limit, plot_limit]);
        box on;
    end

    save_plot(fig, result_dir, 'MLE_Scatter_Comparison');
end

%% ----- 6. Save numerical results -----
results = struct('out', out, 'opts', opts, 'success', success, ...
    'R_original', R_original, 'R_corr', R_corr, ...
    'lambda_min', lambda_min, 'diagonal_shift', diagonal_shift, ...
    'Q0', Q0, 'D0', D0, 'Psi0', Psi0, 'f0', f0, ...
    'grad_norm0', grad_norm0, 'tOpt', tOpt, ...
    'Loadings', Loadings, 'Loadings_rot', Loadings_rot, ...
    'R_rot', R_rot, 'fval_history', fval_history, ...
    'rotation_orth_error', rotation_orth_error, ...
    'rotation_map_error', rotation_map_error, ...
    'covariance_change', covariance_change, ...
    'n_vars', n_vars, 'n_factors', n_factors, 'var_names', {var_names}, ...
    'eigenvalues', eigenvalues, 'cumulative_var', cumulative_var, ...
    'retained_pca_share', retained_pca_share, ...
    'factor_variance', factor_variance, 'factor_share', factor_share, ...
    'common_vs_total', common_vs_total, 'unique_vs_total', unique_vs_total, ...
    'Sigma_opt', Sigma_opt);

save(fullfile(result_dir, 'MLE_results.mat'), '-struct', 'results');
fprintf('\nResults saved to: %s\n', fullfile(pwd, result_dir));
diary off;
end

function print_matrix(label, A, row_labels, column_labels)
fprintf('\n--- %s ---\n', label);
fprintf('%-16s', 'Variable/Factor');
fprintf('%14s', column_labels{:});
fprintf('\n');

for i = 1:size(A, 1)
    fprintf('%-16s', row_labels{i});
    fprintf('%14.4f', A(i, :));
    fprintf('\n');
end
end

function save_plot(fig, folder, name)
saveas(fig, fullfile(folder, [name, '.eps']), 'epsc');
saveas(fig, fullfile(folder, [name, '.fig']), 'fig');
end

function phi = varimax_objective(B)
phi = sum(mean(B .^ 4, 1) - mean(B .^ 2, 1) .^ 2);
end

function [B, R_rot, history] = kaiser_rotation(A, max_rounds, tol)
[p, q] = size(A);
B = A;
R_rot = eye(q);
history = zeros(max_rounds + 1, 1);
history(1) = varimax_objective(B);

for sweep = 1:max_rounds
    for i = 1:(q - 1)
        for j = (i + 1):q
            x = B(:, i);
            y = B(:, j);
            u = x .^ 2 - y .^ 2;
            v = 2 * x .* y;
            cross = u' * v - sum(u) * sum(v) / p;
            balance = sum(u .^ 2 - v .^ 2) - ...
                (sum(u) ^ 2 - sum(v) ^ 2) / p;
            theta = 0.25 * atan2(2 * cross, balance);
            G = [cos(theta), -sin(theta); sin(theta), cos(theta)];
            columns = [i, j];

            B(:, columns) = B(:, columns) * G;
            R_rot(:, columns) = R_rot(:, columns) * G;
        end
    end

    history(sweep + 1) = varimax_objective(B);

    if abs(history(sweep + 1) - history(sweep)) <= tol
        break;
    end
end

history = history(1:(sweep + 1));
end
