function out = RGPRPCG_ML(Q, D, Psi, fun, opts, R)

    % RGPRPCG_ML Riemannian geometric modified PRP-CG method.
    % Stop and report success only when nrmGrad <= opts.gtol.
    % df is the signed change between the last two accepted objective values.
    % Histories include the initial point at index 1 (DF(1) = Inf).

    maxItr = opts.mxitr;

    gtol = opts.gtol;

    delta = 1e-4;

    shrink = 0.2;

    alpha = 0.5;

    mem = 2;

    maxNLS = 20;

    q = size(Q, 2);

    R = 0.5 * (R + R');

    D = diag(diag(D));

    Psi = diag(diag(Psi));

    tStart = tic;

    [F, Gq, Gd, Gpsi, nrmGrad] = fun(Q, D, Psi, R);

    if ~isfinite(F)

        error('RGPRPCG_ML:InitialPoint', 'The initial covariance must be positive definite.');

    end

    nfev = 1;

    itr = 1;

    df = Inf;

    F_old = NaN;

    Zq = -Gq;

    Zd = -Gd;

    Zpsi = -Gpsi;

    Fm = F;

    prodGZ = -nrmGrad ^ 2;

    TT = zeros(maxItr, 1);

    Time = zeros(maxItr, 1);

    DF = Inf(maxItr, 1);

    Fhistory = zeros(maxItr, 1);

    NLS = zeros(maxItr, 1);

    Alpha = zeros(maxItr, 1);

    TT(1) = nrmGrad;

    Fhistory(1) = F;

    converged = nrmGrad <= gtol;

    while itr < maxItr && ~converged

        Q_old = Q;

        D_old = D;

        Psi_old = Psi;

        F_old = F;

        Gq_old = Gq;

        Gd_old = Gd;

        Gpsi_old = Gpsi;

        Zq_old = Zq;

        Zd_old = Zd;

        Zpsi_old = Zpsi;

        nrmGrad_old = nrmGrad;

        alpha_ls = alpha;

        nls = 0;

        % Accept sufficient decrease, or force acceptance at the trial limit.

        while true

            nls = nls + 1;

            [Q_trial, Rqr] = qr(Q_old + alpha_ls * Zq, 0);

            Q_trial = Q_trial * diag(sign(diag(Rqr)));

            D_trial = D_old + alpha_ls * Zd;

            Psi_trial = Psi_old + alpha_ls * Zpsi;

            [F_trial, Gq_trial, Gd_trial, Gpsi_trial, grad_trial] = ...
                fun(Q_trial, D_trial, Psi_trial, R);

            nfev = nfev + 1;

            if (isfinite(F_trial) && F_trial <= max(Fm) + delta * alpha_ls * prodGZ) || ...
                    (nls >= maxNLS)

                break

            end

            alpha_ls = shrink * alpha_ls;

        end

        Q = Q_trial;

        D = D_trial;

        Psi = Psi_trial;

        F = F_trial;

        Gq = Gq_trial;

        Gd = Gd_trial;

        Gpsi = Gpsi_trial;

        nrmGrad = grad_trial;

        df = F - F_old;

        itr = itr + 1;

        TT(itr) = nrmGrad;

        Time(itr) = toc(tStart);

        DF(itr) = df;

        Fhistory(itr) = F;

        NLS(itr) = nls;

        Alpha(itr) = alpha_ls;

        converged = nrmGrad <= gtol;

        if converged

            break

        end

        % Projection transport on the Stiefel component.

        A = Q' * Zq_old;

        TZq = Zq_old - 0.5 * Q * (A + A');

        A = Q' * Gq_old;

        TGq = Gq_old - 0.5 * Q * (A + A');

        Yq = Gq - TGq;

        Yd = Gd - Gd_old;

        Ypsi = Gpsi - Gpsi_old;

        denom = max(nrmGrad_old ^ 2, eps);

        beta = (sum(Gq(:) .* Yq(:)) + ...
                sum(diag(Gd) .* diag(Yd)) + ...
                sum(diag(Gpsi) .* diag(Ypsi))) / denom;

        theta = (sum(Gq(:) .* TZq(:)) + ...
                 sum(diag(Gd) .* diag(Zd_old)) + ...
                 sum(diag(Gpsi) .* diag(Zpsi_old))) / denom;

        beta = max(beta, -1);

        Zq = -Gq + beta * TZq - theta * Yq;

        Zd = -Gd + beta * Zd_old - theta * Yd;

        Zpsi = -Gpsi + beta * Zpsi_old - theta * Ypsi;

        prodGZ = sum(Gq(:) .* Zq(:)) + ...
            sum(diag(Gd) .* diag(Zd)) + ...
            sum(diag(Gpsi) .* diag(Zpsi));

        if ~isfinite(prodGZ) || prodGZ >= 0

            Zq = -Gq;

            Zd = -Gd;

            Zpsi = -Gpsi;

            prodGZ = -nrmGrad ^ 2;

        end

        % Spectral step using the preceding tangent displacement.

        MQ = alpha_ls * Zq_old;

        MD = alpha_ls * diag(Zd_old);

        MPsi = alpha_ls * diag(Zpsi_old);

        Yq = Gq - Gq_old;

        Yd = diag(Gd - Gd_old);

        Ypsi = diag(Gpsi - Gpsi_old);

        aa = sum(MQ(:) .^ 2) + MD' * MD + MPsi' * MPsi;

        bb = abs(sum(MQ(:) .* Yq(:)) + MD' * Yd + MPsi' * Ypsi);

        alpha = min(max(aa / max(bb, eps), 1e-20), 1);

        Fm = [F, Fm];

        Fm = Fm(1:min(mem, numel(Fm)));

    end

    out.Q = Q;

    out.D = D;

    out.Psi = Psi;

    out.fval = F;

    out.fprev = F_old;

    out.nrmGrad = nrmGrad;

    out.df = df;

    out.f_change = df;

    out.abs_df = abs(df);

    out.itr = itr;

    out.TT = TT(1:itr);

    out.Time = Time(1:itr);

    out.DF = DF(1:itr);

    out.Fhistory = Fhistory(1:itr);

    out.NLS = NLS(1:itr);

    out.Alpha = Alpha(1:itr);

    out.nfev = nfev;

    out.nfe = nfev;

    out.feasi_q = norm(Q' * Q - eye(q), 'fro');

    out.success = converged;

    if nrmGrad <= gtol

        out.stop_reason = 'gradient';

    else

        out.stop_reason = 'iteration-limit';

    end

    out.msg = out.stop_reason;

end
