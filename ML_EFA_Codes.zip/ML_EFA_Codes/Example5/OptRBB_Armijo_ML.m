function out = OptRBB_Armijo_ML(Q, D, Psi, fun, opts, R)

    % OPTRBB_ARMIJO_ML Riemannian BB method with monotone Armijo line search.
    % Stop and report success only when nrmGrad <= opts.gtol.
    % df is the signed change between the last two accepted objective values.
    % Histories include the initial point at index 1 (DF(1) = Inf).

    maxItr = opts.mxitr;

    gtol = opts.gtol;

    delta = 1e-4;

    shrink = 0.2;

    alpha = 0.5;

    maxNLS = 20;

    q = size(Q, 2);

    R = 0.5 * (R + R');

    D = diag(diag(D));

    Psi = diag(diag(Psi));

    tStart = tic;

    [F, Gq, Gd, Gpsi, nrmGrad] = fun(Q, D, Psi, R);

    if ~isfinite(F)

        error('OptRBB_Armijo_ML:InitialPoint', 'The initial covariance must be positive definite.');

    end

    nfev = 1;

    itr = 1;

    df = Inf;

    F_old = NaN;

    Zq = -Gq;

    Zd = -Gd;

    Zpsi = -Gpsi;

    TT = zeros(maxItr, 1);

    Time = zeros(maxItr, 1);

    DF = Inf(maxItr, 1);

    Fhistory = zeros(maxItr, 1);

    NLS = zeros(maxItr, 1);

    Alpha = zeros(maxItr, 1);

    TT(1) = nrmGrad;

    Fhistory(1) = F;

    converged = nrmGrad <= gtol;

    while itr < maxItr && ~converged

        Q_old = Q;

        D_old = D;

        Psi_old = Psi;

        F_old = F;

        Gq_old = Gq;

        Gd_old = Gd;

        Gpsi_old = Gpsi;

        alpha_ls = alpha;

        nls = 0;

        % Accept sufficient decrease, or force acceptance at the trial limit.

        while true

            nls = nls + 1;

            [Q_trial, Rqr] = qr(Q_old + alpha_ls * Zq, 0);

            Q_trial = Q_trial * diag(sign(diag(Rqr)));

            D_trial = D_old + alpha_ls * Zd;

            Psi_trial = Psi_old + alpha_ls * Zpsi;

            [F_trial, Gq_trial, Gd_trial, Gpsi_trial, grad_trial] = ...
                fun(Q_trial, D_trial, Psi_trial, R);

            nfev = nfev + 1;

            if (isfinite(F_trial) && F_trial <= F_old - delta * alpha_ls * nrmGrad ^ 2) || ...
                    (nls >= maxNLS)

                break

            end

            alpha_ls = shrink * alpha_ls;

        end

        Q = Q_trial;

        D = D_trial;

        Psi = Psi_trial;

        F = F_trial;

        Gq = Gq_trial;

        Gd = Gd_trial;

        Gpsi = Gpsi_trial;

        nrmGrad = grad_trial;

        df = F - F_old;

        itr = itr + 1;

        TT(itr) = nrmGrad;

        Time(itr) = toc(tStart);

        DF(itr) = df;

        Fhistory(itr) = F;

        NLS(itr) = nls;

        Alpha(itr) = alpha_ls;

        converged = nrmGrad <= gtol;

        if converged

            break

        end

        Zq = -Gq;

        Zd = -Gd;

        Zpsi = -Gpsi;

        % Alternating ambient BB1/BB2 trial steps.

        Sq = Q - Q_old;

        Yq = Gq - Gq_old;

        Sd = diag(D - D_old);

        Yd = diag(Gd - Gd_old);

        Spsi = diag(Psi - Psi_old);

        Ypsi = diag(Gpsi - Gpsi_old);

        SS = sum(Sq(:) .^ 2) + Sd' * Sd + Spsi' * Spsi;

        SY = sum(Sq(:) .* Yq(:)) + Sd' * Yd + Spsi' * Ypsi;

        YY = sum(Yq(:) .^ 2) + Yd' * Yd + Ypsi' * Ypsi;

        if mod(itr, 2) == 0

            alpha = SS / max(abs(SY), eps);

        else

            alpha = abs(SY) / max(YY, eps);

        end

        alpha = min(max(alpha, 1e-20), 1e20);

    end

    out.Q = Q;

    out.D = D;

    out.Psi = Psi;

    out.fval = F;

    out.fprev = F_old;

    out.nrmGrad = nrmGrad;

    out.df = df;

    out.f_change = df;

    out.abs_df = abs(df);

    out.itr = itr;

    out.TT = TT(1:itr);

    out.Time = Time(1:itr);

    out.DF = DF(1:itr);

    out.Fhistory = Fhistory(1:itr);

    out.NLS = NLS(1:itr);

    out.Alpha = Alpha(1:itr);

    out.nfev = nfev;

    out.nfe = nfev;

    out.feasi_q = norm(Q' * Q - eye(q), 'fro');

    out.success = converged;

    if nrmGrad <= gtol

        out.stop_reason = 'gradient';

    else

        out.stop_reason = 'iteration-limit';

    end

    out.msg = out.stop_reason;

end
