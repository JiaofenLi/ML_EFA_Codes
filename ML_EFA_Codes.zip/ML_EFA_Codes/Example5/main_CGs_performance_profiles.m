function main_CGs_performance_profiles

    % MAIN_CGS_PERFORMANCE_PROFILES Performance profiles for seven ML-EFA solvers.
    %
    % The methods are compared in the following order:
    %   1) RBB-ZH (OptGBB)
    %   2) DaiQR-CG
    %   3) RGPRP-CG
    %   4) RZH-CG
    %   5) RG-Armijo
    %   6) RG-ZH
    %   7) RBB-Armijo
    %
    % Two Dolan--More performance profiles are generated, based on:
    %   (i) CPU time; and (ii) iteration count.
    % A run is successful only when its final gradient norm is <= opts.gtol.
    % Objective changes are retained as diagnostics.
    % Failed runs are assigned an infinite performance ratio.

    clc;

    close all;

    diaryFile = 'Seven_Methods_Performance_Profiles_output.txt';

    if exist(diaryFile, 'file')

        delete(diaryFile);

    end

    diary(diaryFile);

    diaryCleanup = onCleanup(@() diary('off')); %#ok<NASGU>

    %% ----- 1. Common Options -----

    opts.gtol  = 1e-4;

    opts.mxitr = 20000;

    baseSeed = 2;

    N_samples = 2000;

    % The sample size is larger than every p, so the sample correlation
    % matrices are not structurally rank deficient merely because p >= N.

    p_list = 30:30:600;

    q_list = [3,5,8,10];

    methodNames = {'Algorithm 3.1', 'DaiQR-CG', 'RGPRP-CG', 'RZH-CG', ...
                   'RG-Armijo', 'RG-ZH', 'RBB-Armijo'};

    methodFuns = {@OptGBB_ML, @DaiQRCG_ML, @RGPRPCG_ML, @RZHCG_ML, ...
                  @OptRG_Armijo_ML, @OptRG_ZH_ML, @OptRBB_Armijo_ML};

    nMethods = numel(methodNames);

    %% ----- 2. Test Problem Configurations -----

    [Pgrid, Qgrid] = ndgrid(p_list, q_list);

    testP = Pgrid(:);

    testQ = Qgrid(:);

    nProblems = numel(testP);

    fprintf('\n================ Test configuration ================\n');

    fprintf('Number of methods : %d\n', nMethods);

    fprintf('Number of problems: %d\n', nProblems);

    fprintf('p values          : ');

    fprintf('%d ', p_list);

    fprintf('\nq values          : ');

    fprintf('%d ', q_list);

    fprintf('\nSample size N     : %d\n', N_samples);

    fprintf('Gradient tolerance: %.1e\n', opts.gtol);

    fprintf('Stop and success rule: nrmGrad <= gtol\n');

    fprintf('====================================================\n\n');

    %% ----- 3. Result Arrays: Problems by Methods -----

    cpuTime = Inf(nProblems, nMethods);

    iterations = Inf(nProblems, nMethods);

    gradNorm = NaN(nProblems, nMethods);

    fValue = NaN(nProblems, nMethods);

    fPrevious = NaN(nProblems, nMethods);

    fChange = Inf(nProblems, nMethods);

    stopReason = cell(nProblems, nMethods);

    success = false(nProblems, nMethods);

    errorMessage = cell(nProblems, nMethods);

    disp('======================================================================================================');

    fprintf('%18s  %4s %3s  %10s  %7s  %12s  %12s    %23s  %9s\n', ...
            'method', 'p', 'q', 'CPU', 'IT', 'nrmGrad',  '|df|', 'Fvalue', 'status');

    disp('----------------------------- ML-EFA seven-method comparison --------------------------------------');

    %% ----- 4. Main Solver Loop -----

    for prob = 1:nProblems

        p = testP(prob);

        q = testQ(prob);

        fprintf('\nProblem %d/%d: (p,q,N)=(%d,%d,%d)\n', ...
                prob, nProblems, p, q, N_samples);

        % A distinct, reproducible data set is generated for every problem.

        rng(baseSeed + prob - 1, 'twister');

        R_true = generate_true_model_ML(p, q);

        X = generate_multivariate_normal(R_true, N_samples);

        R = corrcoef(X);

        R = 0.5 * (R + R');

        % Roundoff safeguard. With N_samples > p, this shift should normally
        % be zero or negligible rather than repairing structural rank loss.

        lamMin = min(eig(R));

        if lamMin < 1e-10

            R = R + (abs(lamMin) + 1e-10) * eye(p);

        end

        [Q0, D0, Psi0] = initialMatrices_ML(R, q);

        for method = 1:nMethods

            tStart = tic;

            try

                out = methodFuns{method}(Q0, D0, Psi0, @fun_ML, opts, R);

                elapsed = toc(tStart);

                % Re-evaluate every final point with the same routine so that
                % the convergence decision is independent of solver caches.

                [fCheck, ~, ~, ~, gCheck] = ...
                    fun_ML(out.Q, out.D, out.Psi, R);

                itr = out.itr;

                df = out.df;

                cpuTime(prob, method) = elapsed;

                iterations(prob, method) = itr;

                gradNorm(prob, method) = gCheck;

                fValue(prob, method) = fCheck;

                fPrevious(prob, method) = out.fprev;

                fChange(prob, method) = df;

                stopReason{prob, method} = out.stop_reason;

                success(prob, method) = gCheck <= opts.gtol;

                if success(prob, method)

                    status = 'SUCCESS';

                else

                    status = 'FAIL';

                end

                fprintf('%18s  %4d %3d  %10.3f  %7d  %12.3e  %12.3e  %10.3f   %9s\n', ...
                        methodNames{method}, p, q, elapsed, itr, gCheck, abs(df), ...
                         fCheck, status);

            catch ME

                elapsed = toc(tStart);

                cpuTime(prob, method) = Inf;

                iterations(prob, method) = Inf;

                success(prob, method) = false;

                errorMessage{prob, method} = ME.message;

                stopReason{prob, method} = 'error';

                fprintf('%18s  %4d %3d  %10.3f  %7s  %12s  %12s  %12s  %23s  %23s  %9s\n', ...
                        methodNames{method}, p, q, elapsed, '---', '---', '---', ...
                        '---', '---', '---', 'ERROR');

                fprintf('  Error message: %s\n', ME.message);

            end

        end

    end

    %% ----- 5. Performance Profile Computations -----
    % Keep the recorded costs; the profile routine masks unsuccessful runs.

    [tauTime, rhoTime, ratioTime] = ...
        compute_performance_profile(cpuTime, success);

    % A successful zero-iteration solve counts as one unit in the ratio only.

    [tauIter, rhoIter, ratioIter] = ...
        compute_performance_profile(max(iterations, 1), success);

    %% ----- 6. Plotting and Saving Performance Profiles -----

    plot_performance_profile(tauTime, rhoTime, methodNames, ...
                             'CPU time ratio', 'Performance Profile: CPU Time', ...
                             'ML_Performance_Profile_CPU_Time_7_Methods');

    plot_performance_profile(tauIter, rhoIter, methodNames, ...
                             'Iteration ratio', 'Performance Profile: Iteration Count', ...
                             'ML_Performance_Profile_Iterations_7_Methods');

    %% ----- 7. Output Final Summary Statistics -----

    metricNames = {'Average CPU time (s)', 'Average iterations', ...
                   'Fastest CPU (%)', 'Fewest iterations (%)', 'Success rate (%)', ...
                   'Successful runs', 'Failed runs', 'Average |df|'};

    rowFormats = {'%18.3f', '%18.1f', '%18.2f', '%18.2f', ...
                  '%18.2f', '%18d', '%18d', '%18.3e'};

    summaryStats = NaN(numel(metricNames), nMethods);

    for method = 1:nMethods

        valid = success(:, method);

        summaryStats(:, method) = [mean(cpuTime(valid, method)); ...
                                   mean(iterations(valid, method)); ...
                                   100 * rhoTime(1, method); 100 * rhoIter(1, method); ...
                                   100 * mean(valid); sum(valid); sum(~valid); ...
                                   mean(abs(fChange(valid & isfinite(fChange(:, method)), method)))];

    end

    fprintf('\n========== Final Summary Statistics ==========\n');

    fprintf('%-25s', 'Metric');

    fprintf('%18s', methodNames{:});

    fprintf('\n%s\n', repmat('-', 1, 25 + 18 * nMethods));

    for metric = 1:numel(metricNames)

        fprintf('%-25s', metricNames{metric});

        fprintf(rowFormats{metric}, summaryStats(metric, :));

        fprintf('\n');

    end

    fprintf('\nAverages use successful runs only; mean |df| also requires an accepted update.\n');

    fprintf('NaN denotes an empty set of eligible runs.\n');

    fprintf('Percentages use all %d problems; ties count for each method.\n', ...
            nProblems);

    fprintf('Success means the final gradient norm satisfies nrmGrad <= gtol.\n');

    %% ----- 8. Export Numerical Results -----

    Summary = table(methodNames(:), summaryStats(1, :).', ...
                    summaryStats(2, :).', summaryStats(3, :).', summaryStats(4, :).', ...
                    summaryStats(5, :).', summaryStats(6, :).', summaryStats(7, :).', ...
                    summaryStats(8, :).', ...
                    'VariableNames', {'Method', 'MeanCPU', 'MeanIterations', ...
                          'FastestCPUPercent', 'FewestIterationsPercent', 'SuccessRatePercent', ...
                          'SuccessfulRuns', 'FailedRuns', 'MeanAbsDeltaF'});

    writetable(Summary, 'ML_Performance_Profile_Summary_7_Methods.csv');

    ProblemID = repelem((1:nProblems)', nMethods);

    pColumn = repelem(testP, nMethods);

    qColumn = repelem(testQ, nMethods);

    NColumn = repmat(N_samples, nProblems * nMethods, 1);

    Method = repmat(methodNames(:), nProblems, 1);

    CPU = reshape(cpuTime.', [], 1);

    IT = reshape(iterations.', [], 1);

    GradNorm = reshape(gradNorm.', [], 1);

    Fvalue = reshape(fValue.', [], 1);

    FPrevious = reshape(fPrevious.', [], 1);

    DeltaF = reshape(fChange.', [], 1);

    AbsDeltaF = abs(DeltaF);

    StopReason = reshape(stopReason.', [], 1);

    Success = reshape(success.', [], 1);

    Error = reshape(errorMessage.', [], 1);

    Results = table(ProblemID, pColumn, qColumn, NColumn, Method, CPU, IT, ...
                    GradNorm, FPrevious, Fvalue, DeltaF, AbsDeltaF, Success, StopReason, Error);

    writetable(Results, 'ML_Performance_Profile_Results_7_Methods.csv');

    save('ML_Performance_Profile_Results_7_Methods.mat', ...
         'Results', 'cpuTime', 'iterations', 'gradNorm', 'fValue', 'success', ...
         'fPrevious', 'fChange', 'stopReason', ...
         'ratioTime', 'ratioIter', 'tauTime', 'tauIter', 'rhoTime', 'rhoIter', ...
         'Summary', 'summaryStats', 'metricNames', 'methodNames', ...
         'opts', 'baseSeed', 'N_samples', 'p_list', 'q_list');

    fprintf('\nInterpretation: rho_s(tau) is the fraction of all test problems for\n');

    fprintf('which method s is within a factor tau of the best successful method.\n');

    fprintf('rho_s(1) is the best-cost fraction; the final ordinate is the success rate.\n');

    diary off;

end

function [tau, rho, ratio] = compute_performance_profile(metric, success)

    % COMPUTE_PERFORMANCE_PROFILE Compute a Dolan--More performance profile.

    [nProblems, nMethods] = size(metric);

    metric(~success | ~isfinite(metric) | metric <= 0) = Inf;

    bestMetric = min(metric, [], 2);

    ratio = Inf(nProblems, nMethods);

    validProblem = isfinite(bestMetric) & (bestMetric > 0);

    ratio(validProblem, :) = metric(validProblem, :) ./ bestMetric(validProblem);

    finiteRatio = ratio(isfinite(ratio));

    tauMax = max([10; finiteRatio(:)]);

    tau = unique([1; logspace(0, log10(tauMax), 400)'; finiteRatio(:)]);

    rho = zeros(numel(tau), nMethods);

    for method = 1:nMethods

        rho(:, method) = mean(bsxfun(@le, ratio(:, method).', tau), 2);

    end

end

function plot_performance_profile(tau, rho, methodNames, xLabelText, ...
                                  titleText, baseName)

    % PLOT_PERFORMANCE_PROFILE Plot and save one seven-method profile.

    nMethods = numel(methodNames);

    colors = lines(nMethods);

    lineStyles = {'-', '--', '-.', ':', '-', '--', '-.'};

    figure('Color', 'w', 'Position', [100, 100, 820, 600]);

    hold on;

    for method = 1:nMethods

        stairs(tau, rho(:, method), ...
               'Color', colors(method, :), ...
               'LineStyle', lineStyles{method}, ...
               'LineWidth', 2.2);

    end

    hold off;

    set(gca, 'XScale', 'log', 'FontSize', 12, 'LineWidth', 1.1);

    xlim([1, max(tau)]);

    ylim([0, 1.02]);

    grid on;

    box on;

    xlabel(['Performance ratio \tau: ', xLabelText], ...
           'FontSize', 13, 'FontWeight', 'bold');

    ylabel('\rho_s(\tau)', 'FontSize', 14, 'FontWeight', 'bold');

    title(titleText, 'FontSize', 14, 'FontWeight', 'bold');

    legend(methodNames, 'Location', 'southeast', 'NumColumns', 2, ...
           'FontSize', 10, 'Interpreter', 'none');

    saveas(gcf, [baseName, '.fig']);

    print(gcf, [baseName, '.eps'], '-depsc2', '-painters');

    print(gcf, [baseName, '.pdf'], '-dpdf', '-painters');

end

function R = generate_true_model_ML(n, q)

    % GENERATE_TRUE_MODEL_ML Create a valid FA correlation matrix.

    A = randn(n, q);

    [Q, ~] = qr(A, 0);

    D = diag(0.8 + 0.4 * rand(q, 1));

    Psi = diag(0.2 + 0.3 * rand(n, 1));

    Sigma = Q * (D .^ 2) * Q' + diag(diag(Psi .^ 2));

    s = 1 ./ sqrt(diag(Sigma));

    R = diag(s) * Sigma * diag(s);

    R = 0.5 * (R + R');

end

function X = generate_multivariate_normal(Sigma, N_samples)

    % GENERATE_MULTIVARIATE_NORMAL Draw N_samples observations from N(0,Sigma).
    % The model generator has strictly positive uniqueness variances.

    n = size(Sigma, 1);

    L = chol(Sigma, 'lower');

    Z = randn(n, N_samples);

    X = (L * Z)';

end

function [Q0, D0, Psi0] = initialMatrices_ML(R, q)

    % INITIALMATRICES_ML PCA-style initialization shared by all methods.

    [Q0, Lambda] = eigs(R, q);

    eigvals = diag(Lambda);

    d2 = max(eigvals - 1, 0);

    D0 = diag(sqrt(d2));

    R_recon = Q0 * (D0 ^ 2) * Q0';

    res = diag(R - R_recon);

    Psi0 = diag(sqrt(max(res, 0.01)));

end
