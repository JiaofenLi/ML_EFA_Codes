function [f, Gq, Gd, Gpsi, nrmGrad] = fun_ML(Q, D, Psi, R)

    % FUN_ML ML-EFA objective and Riemannian gradient in the Frobenius metric.
    % f = log(det(Sigma)) + trace(Sigma \ R).
    % Sigma = Q * D ^ 2 * Q' + Psi ^ 2.
    % Invalid covariance trials return Inf for the line-search test.

    [p, q] = size(Q);

    d = diag(D);

    psi = diag(Psi);

    D2 = diag(d .^ 2);

    Sigma = Q * D2 * Q' + diag(psi .^ 2);

    Sigma = 0.5 * (Sigma + Sigma');

    [L, flag] = chol(Sigma, 'lower');

    if flag ~= 0

        f = Inf;

        Gq = NaN(p, q);

        Gd = diag(NaN(q, 1));

        Gpsi = diag(NaN(p, 1));

        nrmGrad = Inf;

        return

    end

    SigmaInv = L' \ (L \ eye(p));

    f = 2 * sum(log(diag(L))) + trace(SigmaInv * R);

    if nargout == 1

        return

    end

    E = SigmaInv - SigmaInv * R * SigmaInv;

    E = 0.5 * (E + E');

    Gq_e = 2 * E * Q * D2;

    A = Q' * Gq_e;

    Gq = Gq_e - 0.5 * Q * (A + A');

    gd = 2 * d .* diag(Q' * E * Q);

    gpsi = 2 * psi .* diag(E);

    Gd = diag(gd);

    Gpsi = diag(gpsi);

    nrmGrad = sqrt(norm(Gq, 'fro') ^ 2 + gd' * gd + gpsi' * gpsi);

end
