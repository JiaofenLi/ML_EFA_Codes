function out = Lawley(R,Psi,k,opts)
%LAWLEY Classical Lawley iteration for ML factor analysis.
%
% Model:
%
%       Sigma = A*A' + Psi
%
% where Psi is diagonal uniqueness variance matrix.
%
% Input:
%       R       sample covariance/correlation matrix
%       Psi     initial uniqueness variance matrix
%       k       number of factors
%
% Output:
%       out.A
%       out.Psi
%       out.iter
%       out.Psi_change
%       out.Psi_history
%       out.F_history
%       out.f_change
%       out.fval
%       out.KKT_error
%       out.KKT_history
%       out.KKT_loading
%       out.KKT_uniqueness
%       out.KKT_primal
%       out.KKT_dual
%       out.KKT_complementarity
%       out.KKT_satisfied


%% options

psi_tol = opts.ltol;
f_tol = opts.ftol;
maxIter = opts.mxitr_Lawley;
kkt_tol=1e-6;

%% dimension check

[p,~]=size(R);

R=(R+R')/2;

psi=diag(Psi);

%% initialization

[A,fval,SigmaInv]=update_loading(R,psi,k);

F_history=zeros(maxIter,1);

Psi_history=zeros(maxIter,1);

KKT_history=zeros(maxIter,1);


F_history(1)=fval;

Psi_history(1)=norm(psi,inf);

[KKT_error,KKT]=compute_kkt_error(R,A,psi,SigmaInv);

KKT_history(1)=KKT_error;

Psi_change=inf;

f_change=inf;

iter=1;
%% ==================================================
%                   Main iteration
% ===================================================
while iter < maxIter

    psi_old=psi;

    %% Update factor loading

    [A,~]=update_loading(R,psi,k);

    %% Update uniqueness

    psi_new=diag(R-A*A');

    psi_new=max(psi_new,1e-8);

    Psi_change=max(abs(psi_new-psi_old));

    psi=psi_new;

    iter=iter+1;

    Psi_history(iter)=Psi_change;

    %% objective value
    Sigma=A*A'+diag(psi);

    Sigma=(Sigma+Sigma')/2;

    [L,flag]=chol(Sigma,'lower');

    if flag~=0

        error('Sigma is not positive definite.');

    end

    logdetSigma=2*sum(log(diag(L)));

    SigmaInv=L'\(L\eye(p));

    fval=logdetSigma+trace(SigmaInv*R);

    F_history(iter)=fval;

    f_change=abs(F_history(iter)-F_history(iter-1));

    %% KKT residual for the original (A, psi) ML-EFA model

    [KKT_error,KKT]=compute_kkt_error(R,A,psi,SigmaInv);

    KKT_history(iter)=KKT_error;

    %% stopping criterion

    if f_change<=f_tol || KKT_error<=kkt_tol

        break;

    end
end
%% trim

F_history=F_history(1:iter);

Psi_history=Psi_history(1:iter);

KKT_history=KKT_history(1:iter);



%% output
out.A=A;

out.Psi=diag(psi);

out.itr=iter;

out.Psi_change=Psi_change;

out.Psi_history=Psi_history;

out.F_history=F_history;

out.f_change=f_change;

out.fval=fval;

out.kkt_error=KKT_error;

out.KKT_history=KKT_history;

out.KKT_loading=KKT.loading;

out.KKT_uniqueness=KKT.uniqueness;

out.KKT_primal=KKT.primal;

out.KKT_dual=KKT.dual;

out.KKT_complementarity=KKT.complementarity;

out.KKT_tolerance=kkt_tol;

out.KKT_satisfied=(KKT_error<=kkt_tol);

out.f_satisfied=(f_change<=f_tol);

out.Psi_satisfied=(Psi_change<=psi_tol);

out.converged=out.f_satisfied && out.KKT_satisfied;

if iter>=maxIter

    out.msg='Maximum iterations reached.';

else

    out.msg='Convergence achieved.';

end
end



%% ======================================================
% Auxiliary function
% =======================================================

function [A,fval,SigmaInv]=update_loading(R,psi,k)


[p,~]=size(R);



sqrtPsi=sqrt(psi);


invSqrtPsi=1./sqrtPsi;



Rstar=(invSqrtPsi.*R).*invSqrtPsi';

Rstar=(Rstar+Rstar')/2;



[V,D]=eig(Rstar);


lambda=diag(D);



[lambda,idx]=sort(lambda,'descend');


V=V(:,idx);



lambda_k=lambda(1:k);


Q=V(:,1:k);



delta=max(lambda_k-1,1e-8);



A=diag(sqrtPsi)*Q*diag(sqrt(delta));



%% objective


Sigma=A*A'+diag(psi);

Sigma=(Sigma+Sigma')/2;



[L,flag]=chol(Sigma,'lower');


if flag~=0

    error('Sigma is not positive definite.');

end



logdetSigma=2*sum(log(diag(L)));

SigmaInv=L'\(L\eye(p));


fval=logdetSigma+trace(SigmaInv*R);


end


%% ======================================================
% KKT residual for the original ML-EFA parameterization
% =======================================================

function [KKT_error,KKT]=compute_kkt_error(R,A,psi,SigmaInv)
%COMPUTE_KKT_ERROR Verify first-order KKT conditions.
%
% Model:
%       Sigma = A*A' + diag(psi),      psi >= 0.
%
% For the objective
%       F = 1/2*(log(det(Sigma)) + trace(Sigma^{-1}*R)),
% define
%       C = Sigma^{-1} - Sigma^{-1}*R*Sigma^{-1}.
% Then
%       grad_A F   = C*A,
%       grad_psi F = 1/2*diag(C).
%
% With the lower-bound constraint psi >= 0, the KKT conditions are
%       C*A = 0,
%       grad_psi F - mu = 0,
%       psi >= 0, mu >= 0, psi.*mu = 0.

C=SigmaInv-SigmaInv*R*SigmaInv;

C=(C+C')/2;

grad_A=C*A;

grad_psi=0.5*diag(C);

% The multiplier corresponding to psi >= 0 is mu=grad_psi.  The projected
% residual simultaneously handles interior and boundary solutions.
mu=grad_psi;

projected_psi=max(psi-grad_psi,0);

KKT.loading=norm(grad_A,'fro');

KKT.uniqueness=norm(psi-projected_psi,inf);

KKT.primal=norm(min(psi,0),inf);

KKT.dual=norm(min(mu,0),inf);

KKT.complementarity=norm(psi.*mu,inf);

KKT_error=max([KKT.loading,...
               KKT.uniqueness,...
               KKT.primal,...
               KKT.dual,...
               KKT.complementarity]);

KKT.overall=KKT_error;

end
