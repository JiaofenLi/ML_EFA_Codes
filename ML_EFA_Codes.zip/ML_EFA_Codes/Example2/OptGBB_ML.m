function out = OptGBB_ML(Q,D,Psi,fun,opts,R)
%OPTGBB_ML
% OptGBB algorithm for ML factor analysis
%
% Sigma = Q*D^2*Q' + Psi^2
%
% Q: Stiefel manifold
% D,Psi: positive diagonal matrices


%% options

maxItr = opts.mxitr;

gtol = opts.gtol;

ftol = opts.ftol;


delta = 1e-4;
gamma = 0.85;
lambda = 0.2;

alpha = 0.5;



%% dimensions

[p,q]=size(Q);


D=diag(diag(D));
Psi=diag(diag(Psi));

R=(R+R')/2;



%% initial value

[F,Gq,Gd,Gpsi,nrmGrad]=feval(fun,Q,D,Psi,R);


directionQ=-Gq;
directionD=-Gd;
directionPsi=-Gpsi;



%% history

F_history=zeros(maxItr,1);

DF=zeros(maxItr,1);

TT=zeros(maxItr,1);

Time=zeros(maxItr,1);

change_Psi_history=zeros(maxItr,1);



F_history(1)=F;

TT(1)=nrmGrad;

DF(1)=NaN;

change_Psi_history(1)=NaN;



Cval=F;

Qweight=1;


tStart=tic;



%% main iteration

for itr=2:maxItr


    Q_old=Q;
    D_old=D;
    Psi_old=Psi;


    Gq_old=Gq;
    Gd_old=Gd;
    Gpsi_old=Gpsi;



    F_old=F;



    %% BB direction

    directionQ=-Gq;
    directionD=-Gd;
    directionPsi=-Gpsi;



    deriv=delta*nrmGrad^2;


    alpha_ls=alpha;



    %% line search

    for k=1:10


        D_trial=D_old+alpha_ls*directionD;

        Psi_trial=Psi_old+alpha_ls*directionPsi;



        % positivity

        D_trial=diag(max(diag(D_trial),1e-8));

        Psi_trial=diag(max(diag(Psi_trial),1e-8));



        % QR retraction

        [Q_trial,Rq]=qr(Q_old+alpha_ls*directionQ,0);

        s=sign(diag(Rq));

        s(s==0)=1;

        Q_trial=Q_trial*diag(s);



        [F_new,Gq_new,Gd_new,Gpsi_new,nrmGrad_new]=...
            feval(fun,Q_trial,D_trial,Psi_trial,R);



        if isfinite(F_new) && (F_new <= Cval-alpha_ls*deriv || k==20)


            Q=Q_trial;

            D=D_trial;

            Psi=Psi_trial;


            F=F_new;

            Gq=Gq_new;

            Gd=Gd_new;

            Gpsi=Gpsi_new;

            nrmGrad=nrmGrad_new;


            break;

        end


        alpha_ls=lambda*alpha_ls;


    end



    %% record

    df=F-F_old;


    F_history(itr)=F;

    DF(itr)=df;

    TT(itr)=nrmGrad;


    Time(itr)=toc(tStart);



    change_Psi_history(itr)= norm(diag(Psi)-diag(Psi_old),inf);



    f_change=abs(df);



    %% stopping

    if f_change<=ftol || nrmGrad<=gtol

        break;

    end



    %% BB update


    Sq=Q-Q_old;

    Sd=diag(D)-diag(D_old);

    Spsi=diag(Psi)-diag(Psi_old);



    Yq=Gq-Gq_old;

    Yd=diag(Gd)-diag(Gd_old);

    Ypsi=diag(Gpsi)-diag(Gpsi_old);



    SY=sum(Sq(:).*Yq(:))...
        +Sd'*Yd...
        +Spsi'*Ypsi;


    SS=sum(Sq(:).*Sq(:))...
        +Sd'*Sd...
        +Spsi'*Spsi;


    YY=sum(Yq(:).*Yq(:))...
        +Yd'*Yd...
        +Ypsi'*Ypsi;



    if mod(itr,2)==0

        alpha=SS/max(abs(SY),eps);

    else

        alpha=abs(SY)/max(YY,eps);

    end


    alpha=max(min(alpha,1e10),1e-10);



    %% nonmonotone reference


    oldQweight=Qweight;

    Qweight=gamma*oldQweight+1;


    Cval=(gamma*oldQweight*Cval+F)/Qweight;



end



%% trim

F_history=F_history(1:itr);
DF=DF(1:itr);
TT=TT(1:itr);
Time=Time(1:itr);
change_Psi_history=change_Psi_history(1:itr);



%% output

out.Q=Q;

out.D=D;

out.Psi=Psi;


out.fval=F;

out.nrmGrad=nrmGrad;


out.itr=itr;


out.nrmGrad_history=TT;

out.Time=Time;

out.DF=DF;


out.F_history=F_history;

% for main program

out.Psi_history=change_Psi_history;

out.Psi_change=change_Psi_history(end);


out.f_change=abs(DF(end));



out.feasi_q=norm(Q'*Q-eye(q),'fro');



if itr>=maxItr

    out.msg='Maximum iteration reached.';

else

    out.msg='Convergence achieved.';

end



end