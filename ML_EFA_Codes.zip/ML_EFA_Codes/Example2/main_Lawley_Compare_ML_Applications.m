function main_Lawley_Compare_ML_Applications
%MAIN_LAWLEY_COMPARE_ML_APPLICATIONS
% Compare OptGBB and Lawley alternating iteration on 21 real datasets.
%
% Data files:
%   .\Application_datas\data_001.mat
%   ...
%   .\Application_datas\data_021.mat
%
% Each MAT file contains X, R, n and p.  This program uses R, n and p.
%
% All figures and numerical outputs are saved automatically in
%   .\Numerical_results\
%
% Saved files:
%   Command_Window_Output.txt
%   Dataset_01_Scree.fig / .png
%   Dataset_01_Convergence.fig / .png
%   ...
%   Dataset_21_Scree.fig / .png
%   Dataset_21_Convergence.fig / .png
%   ML_FA_Applications_Comparison.csv
%   ML_FA_Applications_Comparison.mat

clc;
close all;
format short e

rng(2,'twister');

%% -------------------- options --------------------
opts.gtol          = 1e-6;
opts.ltol          = 1e-10;
opts.ftol          = 1e-10;
opts.mxitr_Lawley  = 500000;
opts.mxitr         = 50000;

methodLawley = 'Lawley-ALS';
eigFloor = 1e-8;

%% -------------------- folders --------------------
dataDir = fullfile(pwd,'Application_datas');
resultsDir = fullfile(pwd,'Numerical_results');

if ~exist(resultsDir,'dir')
    mkdir(resultsDir);
end

%% -------------------- save Command Window --------------------
diary off
diaryFile = fullfile(resultsDir,'Command_Window_Output.txt');

fid = fopen(diaryFile,'w');
fclose(fid);

diary(diaryFile);

fprintf('Numerical results are saved in:\n%s\n\n',resultsDir);

%% -------------------- storage --------------------
numData = 15;

DatasetID   = (1:numData)';
DatasetName = cell(numData,1);
NumSamples  = zeros(numData,1);
NumVars     = zeros(numData,1);
NumFactors  = zeros(numData,1);
VariancePct = zeros(numData,1);

OptCPU       = zeros(numData,1);
OptIT        = zeros(numData,1);
OptPsiChange = zeros(numData,1);
OptFChange   = zeros(numData,1);
OptFval      = zeros(numData,1);
OptGradNorm  = zeros(numData,1);

LawCPU       = zeros(numData,1);
LawIT        = zeros(numData,1);
LawPsiChange = zeros(numData,1);
LawFChange   = zeros(numData,1);
LawFval      = zeros(numData,1);

%% ========================================================================
%                         21 real datasets
% ========================================================================
for dataID = 1:numData

    %% -------------------- dataset --------------------
    switch dataID
        case 1
            dataFileName = 'data_001.mat';
            dataName = 'Harman74';

        case 2
            dataFileName = 'data_002.mat';
            dataName = 'Ionosphere';

        case 3
            dataFileName = 'data_003.mat';
            dataName = 'wdbc';

        case 4
            dataFileName = 'data_004.mat';
            dataName = 'Spambase';

        case 5
            dataFileName = 'data_005.mat';
            dataName = 'Optical Recognition of Handwritten Digits';

        case 6
            dataFileName = 'data_006.mat';
            dataName = 'Statlog (Landsat Satellite)';

 

        case 7
            dataFileName = 'data_007.mat';
            dataName = 'Arrhythmia';

        case 8
            dataFileName = 'data_008.mat';
            dataName = 'Madelon';


        case 9
            dataFileName = 'data_009.mat';
            dataName = 'Wine Quality (red + white)';

        case 10
            dataFileName = 'data_010.mat';
            dataName = 'Letter Recognition';

        case 11
            dataFileName = 'data_011.mat';
            dataName = 'Dry Bean';


        case 12
            dataFileName = 'data_012.mat';
            dataName = 'QSAR Biodegradation';

        case 13
            dataFileName = 'data_013.mat';
            dataName = 'Mice Protein Expression';

        case 14
            dataFileName = 'data_014.mat';
            dataName = 'Connectionist Bench (Sonar)';


        case 15
            dataFileName = 'data_015.mat';
            dataName = 'Libras Movement';
    end

    DatasetName{dataID} = dataName;

    %% -------------------- load data --------------------
    S = load(fullfile(dataDir,dataFileName),'R','n','p');

    R = double(S.R);
    nObs = double(S.n);
    pVar = double(S.p);

    NumSamples(dataID) = nObs;
    NumVars(dataID) = pVar;

    fprintf('\n\n');
    fprintf('==========================================================================\n');
    fprintf('Dataset %02d/21: %s\n',dataID,dataName);
    fprintf('Observations (n): %d\n',nObs);
    fprintf('Variables    (p): %d\n',pVar);
    fprintf('==========================================================================\n');

    %% -------------------- correlation matrix --------------------
    R = prepareCorrelationMatrix(R,eigFloor);

    %% -------------------- eigenvalues and factor number --------------------
    [eigvals_sorted,~] = sortedEigensystem(R);

    variance_ratio = 100*eigvals_sorted/sum(eigvals_sorted);

    q = sum(eigvals_sorted > 1);
    q = max(q,1);

    cumulativeVariance = sum(variance_ratio(1:q));

    NumFactors(dataID) = q;
    VariancePct(dataID) = cumulativeVariance;

    fprintf('Kaiser criterion : q = %d\n',q);
    fprintf('Variance explained by first %d components: %.4f%%\n', ...
        q,cumulativeVariance);

    %% ====================================================================
    % Scree plot
    % =====================================================================
    figScree = figure('Name',sprintf('Scree Plot - Dataset %02d',dataID), ...
        'NumberTitle','off','Position',[100 100 600 450]);

    plot(1:length(eigvals_sorted), ...
        eigvals_sorted, ...
        'bo-', ...
        'LineWidth',2, ...
        'MarkerSize',6, ...
        'MarkerFaceColor','b');

    hold on;
    yline(1,'r--','LineWidth',1.5);

    xlabel('Principal Component Index','FontSize',12);
    ylabel('Eigenvalue','FontSize',12);

    grid on;

    legend({'Eigenvalues','Eigenvalue = 1'}, ...
        'Location','best');

    hold off;
    drawnow;

    saveFigureResults(figScree,resultsDir, ...
        sprintf('Dataset_%02d_Scree',dataID));

    %% -------------------- initialization --------------------
    [Q0,D0,Psi0] = initialMatrices_ML(R,q);

    %% ====================================================================
    % OptGBB
    % =====================================================================
    tStart = tic;

    outOpt = OptGBB_ML(Q0,D0,Psi0, ...
        @fun_ML,opts,R);

    tOpt = toc(tStart);

    optPsiChange = outOpt.Psi_change;
    optFChange = outOpt.f_change;
    optFval = outOpt.fval;
    optGrad = outOpt.nrmGrad;
    optItr = outOpt.itr;

    optnrmGradHistory = outOpt.nrmGrad_history;
    optFHistory = outOpt.F_history;

    %% ====================================================================
    % Lawley alternating iteration
    % =====================================================================
    psi20 = diag(diag(Psi0).^2);

    tStart = tic;

    outLawley = Lawley(R,psi20,q,opts);

    tLawley = toc(tStart);

    lawPsiChange = outLawley.Psi_change;
    lawFChange = outLawley.f_change;
    lawFval = outLawley.fval;
    lawItr = outLawley.itr;
    lawGrad = outLawley.kkt_error;

    lawnrmGradHistory = outLawley.KKT_history;
    lawFHistory = outLawley.F_history;

    %% -------------------- display --------------------
    fprintf('\n');
    fprintf('%14s %8s %6s %5s %10s %10s %14s %14s %10s %14s\n', ...
        'method','n','p','q','CPU','IT','Psi_change','F_change','fval','grad_norm');
    fprintf('%s\n',repmat('-',1,126));

    fprintf('%14s %8d %6d %5d %10.3f %10d %14.3e %14.3e %10.4f %14.3e\n', ...
        'OptGBB',nObs,pVar,q,tOpt,optItr,optPsiChange,optFChange,optFval,optGrad);

    fprintf('%14s %8d %6d %5d %10.3f %10d %14.3e %14.3e %10.4f %14.3e\n', ...
        methodLawley,nObs,pVar,q,tLawley,lawItr,lawPsiChange,lawFChange,lawFval,lawGrad);

    fprintf('%s\n',repmat('-',1,126));

    %% -------------------- store results --------------------
    OptCPU(dataID)       = tOpt;
    OptIT(dataID)        = optItr;
    OptPsiChange(dataID) = optPsiChange;
    OptFChange(dataID)   = optFChange;
    OptFval(dataID)      = optFval;
    OptGradNorm(dataID)  = optGrad;

    LawCPU(dataID)       = tLawley;
    LawIT(dataID)        = lawItr;
    LawPsiChange(dataID) = lawPsiChange;
    LawFChange(dataID)   = lawFChange;
    LawFval(dataID)      = lawFval;

    %% ====================================================================
    % Convergence curves
    % =====================================================================
    figConv = figure('Name',sprintf('Convergence - Dataset %02d',dataID), ...
        'NumberTitle','off','Position',[100 100 1200 500]);

    subplot(1,2,1);

    semilogy(1:numel(optnrmGradHistory), ...
        optnrmGradHistory, ...
        'r+-', ...
        'LineWidth',1.5);

    hold on;

    semilogy(1:numel(lawnrmGradHistory), ...
        lawnrmGradHistory, ...
        'bD-', ...
        'LineWidth',1.5);

    xlabel('Iteration','FontSize',12);
    ylabel('Gradient norm','FontSize',12);

    grid on;

    legend({'OptGBB','Lawley iteration'}, ...
        'Location','best');

    hold off;

    subplot(1,2,2);

    plot(1:numel(optFHistory), ...
        optFHistory, ...
        'r+-', ...
        'LineWidth',1.5);

    hold on;

    plot(1:numel(lawFHistory), ...
        lawFHistory, ...
        'bD-', ...
        'LineWidth',1.5);

    plot(numel(optFHistory),optFHistory(end),'ro');
    plot(numel(lawFHistory),lawFHistory(end),'bo');

    xlabel('Iteration','FontSize',12);
    ylabel('Objective Function Value','FontSize',12);

    grid on;

    legend({'OptGBB','Lawley iteration'}, ...
        'Location','best');

    hold off;
    drawnow;

    saveFigureResults(figConv,resultsDir, ...
        sprintf('Dataset_%02d_Convergence',dataID));

end

%% ========================================================================
% Final summary
% ========================================================================
Summary = table(DatasetID,DatasetName,NumSamples,NumVars,NumFactors,VariancePct, ...
    OptCPU,OptIT,OptPsiChange,OptFChange,OptFval,OptGradNorm, ...
    LawCPU,LawIT,LawPsiChange,LawFChange,LawFval);

fprintf('\n\n');
fprintf('===============================================================================\n');
fprintf('Summary of all 21 application datasets\n');
fprintf('===============================================================================\n');

fprintf('%3s %-42s %8s %6s %4s %9s %9s %14s %9s %9s %14s\n', ...
    'ID','Dataset','n','p','q','OptCPU','OptIT','OptFval','LawCPU','LawIT','LawFval');
fprintf('%s\n',repmat('-',1,140));

for i = 1:numData
    fprintf('%3d %-42s %8d %6d %4d %9.3f %9d %14.6e %9.3f %9d %14.6e\n', ...
        DatasetID(i),DatasetName{i},NumSamples(i),NumVars(i),NumFactors(i), ...
        OptCPU(i),OptIT(i),OptFval(i),LawCPU(i),LawIT(i),LawFval(i));
end

fprintf('%s\n',repmat('-',1,140));

csvFile = fullfile(resultsDir,'ML_FA_Applications_Comparison.csv');
matFile = fullfile(resultsDir,'ML_FA_Applications_Comparison.mat');

writetable(Summary,csvFile);
save(matFile,'Summary');

fprintf('\nAll numerical results and figures are saved in:\n%s\n',resultsDir);

diary off

end


%% ========================================================================
% Save figure
% ========================================================================
function saveFigureResults(figHandle,resultsDir,fileStem)

savefig(figHandle,fullfile(resultsDir,[fileStem '.fig']));

set(figHandle,'PaperPositionMode','auto');
print(figHandle, ...
    fullfile(resultsDir,[fileStem '.png']), ...
    '-dpng','-r300');

end


%% ========================================================================
% Prepare correlation matrix
% ========================================================================
function R = prepareCorrelationMatrix(R,eigFloor)

R = 0.5*(R+R');

[V,Lambda] = eig(R);
lambda = max(real(diag(Lambda)),eigFloor);

R = V*diag(lambda)*V';
R = real(0.5*(R+R'));

d = sqrt(diag(R));
R = R./(d*d');
R = real(0.5*(R+R'));

end


%% ========================================================================
% Sorted eigensystem
% ========================================================================
function [eigvals_sorted,Vsorted] = sortedEigensystem(R)

[V,Lambda] = eig(R);
[eigvals_sorted,idx] = sort(real(diag(Lambda)),'descend');
Vsorted = real(V(:,idx));

end


%% ========================================================================
% PCA-style initialization
% ========================================================================
function [Q0,D0,Psi0] = initialMatrices_ML(R,q)

[eigvals,U] = sortedEigensystem(R);

Q0 = U(:,1:q);

d2 = max(eigvals(1:q)-1,1e-6);
D0 = diag(sqrt(d2));

R_recon = Q0*(D0^2)*Q0';
res = real(diag(R-R_recon));

Psi0 = diag(sqrt(max(res,1e-6)));

end
