function [f, Gq, Gd, Gpsi, nrmGrad] = fun_ML(Q, D, Psi, R)
%FUN_ML  Maximum-likelihood factor analysis objective and Riemannian gradients.
%
% This function implements the negative log-likelihood objective used in
% maximum-likelihood factor analysis under a multivariate normal model.
%
% Objective:
%   f(Q, D, Psi) = log(det(Sigma)) + trace(Sigma^{-1} * R),
% where
%   Sigma = Q * D^2 * Q' + Psi^2.
%
% Here Q lies on the Stiefel manifold (orthonormal columns), while D and Psi
% are diagonal matrices. R is a given sample correlation (or covariance)
% matrix.
%
% Inputs
%   Q     - Orthonormal matrix of size p-by-q (Q'*Q = I_q)
%   D     - Diagonal matrix of size q-by-q (factor scales)
%   Psi   - Diagonal matrix of size p-by-p (unique variances)
%   R     - Symmetric positive semidefinite matrix of size p-by-p
%
% Outputs
%   f       - Objective value (negative log-likelihood up to a constant)
%   Gq      - Riemannian gradient with respect to Q (p-by-q)
%   Gd      - Riemannian gradient with respect to D (q-by-q, diagonal)
%   Gpsi    - Riemannian gradient with respect to Psi (p-by-p, diagonal)
%   nrmGrad - Frobenius norm of the full Riemannian gradient

% ---- sizes ----
[p, q] = size(Q);

% ---- enforce symmetry/diagonal structure (harmless) ----
R   = 0.5 * (R + R');
D   = diag(diag(D));
Psi = diag(diag(Psi));

% ---- build Sigma ----
D2   = D * D;
Psi2 = Psi * Psi;
Sigma = Q * D2 * Q' + Psi2;
Sigma = 0.5 * (Sigma + Sigma');

% ---- stable inverse and logdet via Cholesky ----
[L, flag] = chol(Sigma, 'lower');
if flag ~= 0
    % minimal diagonal shift to make Sigma SPD
    minEig = min(eig(Sigma));
    shift  = max(1e-10, -minEig + 1e-10);
    Sigma  = Sigma + shift * eye(p);
    L      = chol(Sigma, 'lower');
end
logDetSigma = 2 * sum(log(diag(L)));
SigmaInv    = L' \ (L \ eye(p));   % Sigma^{-1}

% ---- objective ----
f = logDetSigma + trace(SigmaInv * R);

% ---- Euclidean derivative wrt Sigma ----
E = SigmaInv - SigmaInv * R * SigmaInv;
E = 0.5 * (E + E');  % keep symmetric

% ---- gradients ----
% Q: project Euclidean gradient onto Stiefel tangent
Gq_e = 2 * E * Q * D2;
QG   = Q' * Gq_e;
Gq   = Gq_e - 0.5 * Q * (QG + QG');

% D, Psi: keep only diagonal directions (diagonal constraints)
C    = Q' * E * Q;
Gd   = 2 * diag(diag(D)   .* diag(C));  Gd   = diag(diag(Gd));
Gpsi = 2 * diag(diag(Psi) .* diag(E));  Gpsi = diag(diag(Gpsi));

% ---- gradient norm ----
nrmGrad = sqrt( norm(Gq,'fro')^2 + norm(Gd,'fro')^2 + norm(Gpsi,'fro')^2 );

end
