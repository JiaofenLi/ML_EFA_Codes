function main_Manopt_Compare_ML
%MAIN_Manopt_COMPARE_ML  Compare RGPRPCG vs. Manopt solvers for ML factor analysis.
%
% This script:
%   1) Generates a true ML factor-analysis correlation matrix R_true.
%   2) Draws samples from N(0, R_true).
%   3) Builds sample correlation matrix R.
%   4) Runs RGPRPCG and Manopt-based methods.


clc;
close all;
%% ----- Start logging command window output to a text file -------------
diaryFile = 'Manopt_Compare_ML_output.txt';
if exist(diaryFile, 'file')
    clear(diaryFile);    % remove existing file to avoid appending old content
end
diary(diaryFile);         % start logging

%% ================================================================
%% -------------------- options --------------------
opts.gtol        = 1e-6;
opts.mxitr = 20000;
opts.gtol_optGBB = 1e-6;

%% -------------------- display header --------------------
disp('======================================================================');
fprintf('%15s\t %2s %2s\t %4s\t %5s\t %5s\t %13s\n', ...
    'method', 'p', 'q', 'CPU', 'IT', 'nrmg', 'Fvalue');
disp('----ML Factor Analysis-----');

%% -------------------- test cases --------------------
p_list = [30, 30,30, 60,60,60,100, 100, 100,300,300,300,500,500,500,1000,1000,1000];   % number of variables
q_list = [ 2,  5, 8,  3, 5,10,  5,   8,  15,  5,  8, 15,  5, 15, 10,   5,  10,  13];   % number of factors


N_samples = 2000;                % sample size for building sample correlation

for kCase = 1:numel(p_list)
    p = p_list(kCase);
    q = q_list(kCase);

    %% ----- build sample correlation matrix R -----
    R_true = generate_true_model_ML(p, q);
    X      = generate_multivariate_normal(R_true, N_samples); % N_samples-by-n
    R      = corrcoef(X);
    R      = 0.5 * (R + R');

    % Ensure positive definiteness (small diagonal shift if needed)
    lamMin = min(eig(R));
    if lamMin < 1e-8
        R = R + (abs(lamMin) + 1e-8) * eye(p);
    end

    %% ----- initialization -----
    [Q0, D0, Psi0] = initialMatrices_ML(R, q);

    %% ----- OptGBB -----
    tStart = tic;
    outOpt = OptGBB_ML(Q0, D0, Psi0, @fun_ML, opts, R);
    tOpt   = toc(tStart);
    TT_OptGBB=outOpt.TT;
    TIME_OptGBB=outOpt.Time;
fprintf('%15s\t %s%d %d%s\t %3.3f\t %5d\t %4.1e\t %10.4f\t\n', ...
        'OptGBB', '[',p,q,']', tOpt, outOpt.itr, outOpt.nrmGrad, outOpt.fval);
    
    % =================================================================
    % Manopt-based solvers
    % =================================================================
    options.tolgradnorm      = 1e-6;
    options.maxiter   = 20000;
    options.verbosity = 0;
    options.minstepsize=1e-20;
    [problem, Y] = setupManoptProblem(Q0, D0, Psi0, R);

    methods = {'RCG-Manopt', 'RBB-Manopt', 'RSD-Manopt', 'RTR-Manopt','RLBFGS-Manopt','ARC-Manopt'};
    for method_idx=1:numel(methods)
        method=methods{method_idx};
        tic
        switch method
            case 'RCG-Manopt'
                [~, fval, info] = conjugategradient(problem,Y,options);
                TT_CG=[info.gradnorm];
                TIME_CG=[info.time];
            case 'RBB-Manopt'
                [~, fval, info] = barzilaiborwein(problem,Y,options);
                TT_BB=[info.gradnorm];
                TIME_BB=[info.time];
            case 'RSD-Manopt'
                [~, fval, info] = steepestdescent(problem,Y,options);
                TT_SD=[info.gradnorm];
                TIME_SD=[info.time];
            case 'RTR-Manopt'
                [~, fval, info] = trustregions(problem,Y,options);
                TT_RTR=[info.gradnorm];
                TIME_RTR=[info.time];
            case 'RLBFGS-Manopt'
                [~, fval, info] = rlbfgs(problem,Y,options);
                TT_RLBFGS=[info.gradnorm];
                TIME_RLBFGS=[info.time];
            case 'ARC-Manopt'
                [~, fval, info]=arc(problem,Y,options);
                TT_ARC=[info.gradnorm];
                TIME_ARC=[info.time];
        end
        time=toc;
        fprintf('%15s\t %s%d %d%s\t %3.3f\t %5d\t %4.1e\t %10.4f\t \n', ...
            method, '[',p,q,']',time,info(end).iter, info(end).gradnorm,fval);
    end
    disp('----------------------------------------------------------------------');

    %% ----------Figures---------------------------------------------
    figure(kCase)
    hold on
    marker_shapes = {'s', 'o', '^', 'd', 'p', 'h', '+', '*', 'x', '.', 'v', '<', '>', '|', '_'};
    colors = [0 0 1; 1 0 0; 0 1 0; 0 1 1; 1 0 1; 0 0 0; 1 0.5 0; 0.5 0.5 1; 1 0.5 1; 0.5 1 0.5; 0.5 1 1; 1 1 0.5];
    % blue-1, red-2, green-3, cyan-4, magenta-5, black-6, orange-7,
    %light blue-8, pink-9, light green-10, light cyan-11, light yellow-12

    % Plot Error vs Iteration times
    plot(TIME_OptGBB,log10(TT_OptGBB), 'Color',  colors(2, :), 'Marker', marker_shapes{2}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_CG,log10(TT_CG), 'Color', colors(1, :), 'Marker', marker_shapes{10}, 'LineStyle', '-', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_BB,log10(TT_BB), 'Color', colors(3, :), 'Marker', marker_shapes{15}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_SD,log10(TT_SD), 'Color', colors(7, :), 'Marker', marker_shapes{7}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_RTR,log10(TT_RTR), 'Color', colors(8, :), 'Marker', marker_shapes{8}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_RLBFGS,log10(TT_RLBFGS), 'Color', colors(9, :), 'Marker', marker_shapes{9}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    plot(TIME_ARC,log10(TT_ARC), 'Color', colors(6, :), 'Marker', marker_shapes{5}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);

    legend_labels = {'Algorithm 3.1','RCG-Manopt','RBB-Manopt','RSD-Manopt','RTR-Manopt','RLBFGS-Manopt','ARC-Manopt'};
    h = legend(legend_labels, 'NumColumns',2);
    set(h,'Fontsize',10, 'FontWeight', 'bold','Location', 'Northeast');
    xlabel('Time (s)','FontSize',20);
    ylabel('$\textrm{log}_{10}\|\textrm{grad} f(Z^{(k)}) \|$','Interpreter','latex','fontsize',10)
    set(gca,'LineWidth',1)
    set(gca,'FontSize',15)
    title(['ML-EFA', ',  (p, q)=','(',num2str(p),', ',num2str(q),')'],'fontsize',16,'FontWeight', 'bold')

    hold off

    box off
    ax1 = axes('Position',get(gca,'Position'),'XAxisLocation','top',...
        'YAxisLocation','right','Color','none','XColor','w','YColor','w');
    set(ax1,'XTick', [],'YTick', []);
    hold off

    %% save the figures
    epsname = sprintf('ML-EFA-p=%d_q=%d.eps',  p, q);saveas(gcf, epsname, 'epsc');
    figname = sprintf('ML-EFA-p=%d_q=%d.fig',  p, q);saveas(gcf, figname);


end
%% ----- Stop logging ----------------------------------------------------
diary off;
%% ================================================================
end


%% ======================================================================
%  Helper: true ML factor-analysis correlation matrix (R_true)
% ======================================================================
function R = generate_true_model_ML(n, q)
%GENERATE_TRUE_MODEL_ML  Create a valid correlation matrix from an FA model.

%rng(42, 'twister');  % reproducibility

% Orthonormal loading directions
A = randn(n, q);
[Q, ~] = qr(A, 0);

% Positive factor and unique variances
D   = diag(0.8 + 0.4 * rand(q, 1));
Psi = diag(0.2 + 0.3 * rand(n, 1));

Sigma = Q * (D.^2) * Q' + diag(diag(Psi.^2));

% Convert covariance to correlation
s = 1 ./ sqrt(diag(Sigma));
R = diag(s) * Sigma * diag(s);
R = 0.5 * (R + R');
end

%% ======================================================================
%  Helper: sample from N(0, Sigma)
% ======================================================================
function X = generate_multivariate_normal(Sigma, N_samples)
%GENERATE_MULTIVARIATE_NORMAL  Draw N_samples from N(0, Sigma).
% Output X is N_samples-by-n (rows are samples).

n = size(Sigma, 1);

% Ensure positive definiteness
lamMin = min(eig(Sigma));
if lamMin < 1e-8
    Sigma = Sigma + (abs(lamMin) + 1e-8) * eye(n);
end

% Cholesky factor (fallback to SVD if needed)
[L, flag] = chol(Sigma, 'lower');
if flag ~= 0
    [U, S, ~] = svd(Sigma);
    L = U * sqrt(S);
end

Z = randn(n, N_samples);
X = (L * Z)';  % N_samples-by-n
end

%% ======================================================================
%  Helper: PCA-style initialization for (Q0, D0, Psi0)
% ======================================================================
function [Q0, D0, Psi0] = initialMatrices_ML(R, q)
%INITIALMATRICES_ML  Simple PCA-based initialization for ML factor analysis.

[U, Lambda] = eigs(R, q);
Q0 = U;

eigvals = diag(Lambda);

% Simple ML-style heuristic: D^2 roughly equals (eigs - 1) if R is correlation-like.
d2 = max(eigvals - 1, 0);
D0 = diag(sqrt(d2));

R_recon = Q0 * (D0^2) * Q0';
res = diag(R - R_recon);

Psi0 = diag(sqrt(max(res, 0.01))); % avoid zeros
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Prepare Manopt problem setup
function [problem, Y] = setupManoptProblem(Q0, D0, Psi0, R)
%SETUPMANOPTPROBLEM_ML  Manopt model for ML factor analysis.
%
% We use a product manifold:
%   Q   : Stiefel(p,q)
%   D   : diagonal subspace in R^{q x q}
%   Psi : diagonal subspace in R^{p x p}

[p, q] = size(Q0);

E_q = euclideanfactory(q, q);
E_p = euclideanfactory(p, p);

projDiag = @(X) diag(diag(X));

M.Q   = stiefelfactory(p, q);
M.D   = euclideansubspacefactory(E_q, projDiag, q);
M.Psi = euclideansubspacefactory(E_p, projDiag, p);

problem.M = productmanifold(M);
problem.cost = @(Y) cost(Y, R);
problem.grad = @(Y) grad(Y, R);
problem.hess = @(Y, Z) hess(Y, Z, R);

Y.Q = Q0;
Y.D = D0;
Y.Psi = Psi0;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function f = cost(Y, R)
Q = Y.Q;
D = Y.D;
Psi = Y.Psi;
% ---- sizes ----
[p, q] = size(Q);

% ---- enforce symmetry/diagonal structure (harmless) ----
R   = 0.5 * (R + R');
D   = diag(diag(D));
Psi = diag(diag(Psi));

% ---- build Sigma ----
D2   = D * D;
Psi2 = Psi * Psi;
Sigma = Q * D2 * Q' + Psi2;
Sigma = 0.5 * (Sigma + Sigma');

% ---- stable inverse and logdet via Cholesky ----
[L, flag] = chol(Sigma, 'lower');
if flag ~= 0
    % minimal diagonal shift to make Sigma SPD
    minEig = min(eig(Sigma));
    shift  = max(1e-10, -minEig + 1e-10);
    Sigma  = Sigma + shift * eye(p);
    L      = chol(Sigma, 'lower');
end
logDetSigma = 2 * sum(log(diag(L)));
SigmaInv    = L' \ (L \ eye(p));   % Sigma^{-1}

% ---- objective ----
f = logDetSigma + trace(SigmaInv * R);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function g = grad(Y, R)
Q = Y.Q;
D = Y.D;
Psi = Y.Psi;
[p, q] = size(Q);

% ---- build Sigma ----
D2   = D * D;
Psi2 = Psi * Psi;
Sigma = Q * D2 * Q' + Psi2;
Sigma = 0.5 * (Sigma + Sigma');

% ---- stable inverse and logdet via Cholesky ----
[L, flag] = chol(Sigma, 'lower');
if flag ~= 0
    % minimal diagonal shift to make Sigma SPD
    minEig = min(eig(Sigma));
    shift  = max(1e-10, -minEig + 1e-10);
    Sigma  = Sigma + shift * eye(p);
    L      = chol(Sigma, 'lower');
end

SigmaInv    = L' \ (L \ eye(p));   % Sigma^{-1}


% ---- Euclidean derivative wrt Sigma ----
E = SigmaInv - SigmaInv * R * SigmaInv;
E = 0.5 * (E + E');  % keep symmetric

% ---- gradients ----
% Q: project Euclidean gradient onto Stiefel tangent
Gq_e = 2 * E * Q * D2;
QG   = Q' * Gq_e;
Gq   = Gq_e - 0.5 * Q * (QG + QG');
g.Q = Gq;

% D, Psi: keep only diagonal directions (diagonal constraints)
C    = Q' * E * Q;
Gd   = 2 * diag(diag(D)   .* diag(C));
Gd   = diag(diag(Gd));
g.D = Gd;

Gpsi = 2 * diag(diag(Psi) .* diag(E));
Gpsi = diag(diag(Gpsi));
g.Psi= Gpsi;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Hess = hess(Y, Z, R)
Q = Y.Q;
D = Y.D;
Psi = Y.Psi;

Zq = Z.Q;
Zd = Z.D;
Zpsi = Z.Psi;

[p, q] = size(Q);

% Diagonal squares
D2   = D.^2;
Psi2 = Psi.^2;

% Sigma and inverse (use Cholesky when possible)
Sigma = Q * D2 * Q' + Psi2;
Sigma = 0.5 * (Sigma + Sigma');  % enforce symmetry

[Lc, flag] = chol(Sigma, 'lower');
if flag == 0
    log_det_ok = true; %#ok<NASGU>
    Linv = Lc \ eye(p);
    Sinv = Linv' * Linv;
else
    % Robust fallback
    [U, S, V] = svd(Sigma);
    s = diag(S);
    s = max(s, 1e-12);
    Sinv = V * diag(1 ./ s) * U';
end

% Y = d/dSigma [ logdet + tr(Sinv R) ] = Sinv - Sinv*R*Sinv
Y = Sinv - Sinv * R * Sinv;

% Directional derivative of E:
% dE = -Sinv*(dSigma)*Sinv + Sinv*(dSigma)*Sinv*R*Sinv + Sinv*R*Sinv*(dSigma)*Sinv
%    = -Sinv*dSigma*Sinv + Sinv*dSigma*(Sinv*R*Sinv) + (Sinv*R*Sinv)*dSigma*Sinv
M = Sinv * R * Sinv;

% dSigma = d(Q D^2 Q') + d(Psi^2)
% d(Q D^2 Q') = Zq*D^2*Q' + Q*D^2*Zq' + Q*d(D^2)*Q'
% with d(D^2) = 2*D*Zd (since D and Zd are diagonal)
dD2 = 2 * (D .* Zd);
dD2 = diag(diag(dD2)); % ensure diagonal

dSigma = Zq * D2 * Q' + Q * D2 * Zq' + Q * dD2 * Q' + 2 * (Psi .* Zpsi);
dSigma = 0.5 * (dSigma + dSigma'); % enforce symmetry

dY = -Sinv * dSigma * Sinv + Sinv * dSigma * M + M * dSigma * Sinv;

% Euclidean Hessian directions:
% d/dt (Gq_eucl) = 2*( dE*Q*D^2 + E*Zq*D^2 + E*Q*d(D^2) )
EH_Q = 2 * (dY * Q * D2 + Y * Zq * D2 + Y * Q * dD2);

% d/dt (Gd_eucl) where Gd_eucl = 2*diag(diag(D).*diag(Q'*E*Q))
C  = Q' * Y  * Q;
dC = Zq' * Y * Q + Q' * dY * Q + Q' * Y * Zq;

diagD  = diag(D);
diagZd = diag(Zd);

Hd_vec = 2 * (diagZd .* diag(C) + diagD .* diag(dC));
EH_D  = diag(Hd_vec);

% d/dt (Gpsi_eucl) where Gpsi_eucl = 2*diag(diag(Psi).*diag(E))
diagPsi  = diag(Psi);
diagZpsi = diag(Zpsi);

Hpsi_vec = 2 * (diagZpsi .* diag(Y) + diagPsi .* diag(dY));
EH_Psi = diag(Hpsi_vec);

% Project Q-Hessian to tangent space at Q (Stiefel)
B= 2* C * D2;
EH_Q = EH_Q - 0.5* Zq * (B + B');

A  = Q' * EH_Q;
HessQ = EH_Q - 0.5 * Q * (A + A');

% Diagonal spaces: keep diagonal only
HessD   = diag(diag(EH_D));
HessPsi = diag(diag(EH_Psi));

Hess.Q   = HessQ;
Hess.D   = HessD;
Hess.Psi = HessPsi;

end
